import math as m

class TicTacToeWithMinimax:

    def __init__(self):
        self.board = [['' for i in range(3)] for y in range(3)]
        self.ai = "X"
        self.hum = "O"

        # current Player
        self.curr = self.ai

        self.scores = {
            'tie': 0,
            'X': 10,
            'O': -10
        }
    
    def askForStarter(self):
        """
            ask user if computer should make first move or not
        """
        ans = input("Wenn du willst, dass der Computer den ersten Zug erhält, dann gebe wieder 1 ein. Bei allem anderen fängst du an. \n")
        self.curr = self.ai if ans == "1" else self.hum
        print("Der Computer beginnt!\n") if self.curr == self.ai else print("Du beginnst!\n")

    def checkPlayerAcceptence(self):
        """
            ask player if they are ready
        """
        ans = input("Wenn du bereit bist, gebe bitte die Zahl 1 (nicht mehr und nicht weniger) ein.\n")
        if not ans == "1":
            self.checkPlayerAcceptence()
        self.askForStarter()

    def printWelcome(self):
        print("Hallöchen und Willkommen zu TICTACTOE!")
        print("Du wirst gleich gegen eine TicTacToe AI spielen (also bereite schonmal die Taschentücher zum weinen vor, denn Erfolgerlebnisse wirst du heute nicht haben!)")
        print("Das Brett wird so aussehen:")
        print("| 1 | 2 | 3 |")
        print("| 4 | 5 | 6 |")
        print("| 7 | 8 | 9 |")
        print()
        print("Die Zahlen innerhalb des Tic Tac Toe Feldes, symbolisieren den Index den du Eintragen musst.")
        self.checkPlayerAcceptence()

    def checkTriples(self, x, y, z) -> bool:
        """
            check if the three passed in values are equal
        """
        return x == y and y == z and not x == ''

    def checkWinner(self) -> str:
        """
            check if the game has been won or a tie occured
        """
        winner = None

        for i in range(3):
            if self.checkTriples(self.board[i][0], self.board[i][1], self.board[i][2]):
                winner = self.board[i][0]
            elif self.checkTriples(self.board[0][i], self.board[1][i], self.board[2][i]):
                winner = self.board[0][i]
        if self.checkTriples(self.board[0][0], self.board[1][1], self.board[2][2]):
            winner = self.board[0][0]
        elif self.checkTriples(self.board[0][2], self.board[1][1], self.board[2][0]):
            winner = self.board[2][0]
        
        open = 0
        for i in self.board:
            for j in i:
                if j == '':
                    open += 1
        
        if winner == None and open == 0:
            return 'tie'
        else:
            return winner

    def setMove(self, a, b):
        """
            receives indices of the place where a symbol should be set
        """
        # in this case only the human player uses setMove. So it will be set directly.
        if self.board[a][b] == '':
            self.board[a][b] = self.hum
        else:
            print("Besetzt! Setze es woanders! [1-9]\n")
            self.printBoard()
            playerChoice = int(input("Wo soll dein zug hin[1-9]: "))
            self.getAccordingListIndices(playerChoice)

    def getAccordingListIndices(self, a):
        """
            convert the numeral TicTacToeField Spot into 2D-coordinates
        """
        if a == 1:
            self.setMove(0,0)
        elif a == 2:
            self.setMove(0,1)
        elif a == 3:
            self.setMove(0,2)
        elif a == 4:
            self.setMove(1,0)
        elif a == 5:
            self.setMove(1,1)
        elif a == 6:
            self.setMove(1,2)
        elif a == 7:
            self.setMove(2,0)
        elif a == 8:
            self.setMove(2,1)
        elif a == 9:
            self.setMove(2,2)

    def printBoard(self):
        printing = self.board[:]
        print("--------------")
        print("| " + str("-" if printing[0][0] == "" else printing[0][0]) + " | " + str("-" if printing[0][1] == "" else printing[0][1]) + " | " + str("-" if printing[0][2] == "" else printing[0][2])+ " |")
        print("| " + str("-" if printing[1][0] == "" else printing[1][0]) + " | " + str("-" if printing[1][1] == "" else printing[1][1]) + " | " + str("-" if printing[1][2] == "" else printing[1][2])+ " |")
        print("| " + str("-" if printing[2][0] == "" else printing[2][0]) + " | " + str("-" if printing[2][1] == "" else printing[2][1]) + " | " + str("-" if printing[2][2] == "" else printing[2][2])+ " |")

    def playGame(self):
        """
            Runs through the whole game turn process and prints winner of the tic tac toe game in the end
        """
        self.printWelcome()
        while self.checkWinner() == None:
            if self.curr == self.ai:  
                self.findBestMove()
                if not self.checkWinner() == None:
                    self.printBoard()
                    break
            self.printBoard()
            playerChoice = int(input("Wo soll dein zug hin[1-9]: "))
            self.getAccordingListIndices(playerChoice)
            self.curr = self.ai
            if not self.checkWinner() == None:
                break
        self.printBoard()
        if self.checkWinner() == "tie":
            print("Unentschieden!!")
        else:
            print("Der Computer hat gewonnen!") if self.checkWinner() == self.ai else print("Der Spieler hat gewonnen! (Schummler)")

    # MINIMAX METHODS

    def maximize(self, board) -> int:
        """
            tries to maximize the value of tic tac toe game
        """
        best = -m.inf
        for i in range(3):
            for j in range(3):
                if board[i][j] == '':
                    board[i][j] = self.ai
                    score = self.minimax(board, False)
                    board[i][j] = ''
                    # check which number is bigger and assign to best
                    best = max(score, best)
        return best 
    
    def minimize(self, board) -> int:
        """
            tries to minimize the value of tic tac toe game
        """
        best = m.inf
        for i in range(3):
            for j in range(3):
                if board[i][j] == '':
                    board[i][j] = self.hum
                    score = self.minimax(board, True)
                    board[i][j] = ''
                    # check which number is smaller and assign to best
                    best = min(score, best)
        return best

    def minimax(self, board, isMaximizing) -> int:
        """
            minimax method -> calls the Functions for maximizer/minimizer
        """
        result = self.checkWinner()
        # if someone won -> return the value of winner | X: 10, O: -10: TIE: 0
        if not result == None:
            return self.scores[result]

        if isMaximizing:
            return self.maximize(board)
        else:
            return self.minimize(board) 

    def findBestMove(self):
        """
            starts the move searching process for the computer with minimax
        """
        best = -m.inf
        move = None
        for i in range(3):
            for j in range(3):
                if self.board[i][j] == '':
                    self.board[i][j] = self.ai
                    # call minimax as minimizer -> because next move is the move for the human and so on ...
                    score = self.minimax(self.board, False)
                    self.board[i][j] = ''
                    if score > best:
                        best = score
                        move = [i, j]
        if not move == None:
            self.board[move[0]][move[1]] = self.ai
            self.curr = self.hum



if __name__== "__main__" :
    A = TicTacToeWithMinimax()
    A.playGame()