package DrawTest;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.jzy3d.chart.Chart;
import org.jzy3d.chart.factories.AWTChartFactory;
import org.jzy3d.chart.factories.AWTPainterFactory;
import org.jzy3d.chart.factories.IChartFactory;
import org.jzy3d.chart.factories.IPainterFactory;
import org.jzy3d.colors.Color;
import org.jzy3d.maths.Coord3d;
import org.jzy3d.plot3d.primitives.Scatter;
import org.jzy3d.plot3d.rendering.canvas.Quality;

import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLProfile;


public class ScatterDemoAWT  {
  public static void main(String[] args) {

    // Generate scatter data
    int size = 5000;
    float x;
    float y;
    float z;

    Coord3d[] points = new Coord3d[size];
    Color[] colors = new Color[size];

    Random r = new Random();
    r.setSeed(0);

    for (int i = 0; i < size; i++) {
    	if (r.nextFloat() <= 0.5) {
    	  x = (r.nextFloat()) * 100f;
    	} else {
      	  x = 400f + (r.nextFloat() - 0.5f) * 100f;	
    	}
    	
    	if (r.nextFloat() <= 0.5) {
      	  y = (r.nextFloat()) * 100f;
      	} else {
      	  y = 400f + (r.nextFloat() - 0.5f) * 100f;	
      	}
      
    	if (r.nextFloat() <= 0.5) {
        	  z = (r.nextFloat()) * 100f;
        } else {
        	  z = 400f + (r.nextFloat() - 0.5f) * 100f;	
        }
      
      points[i] = new Coord3d(x, y, z);
      colors[i] = new Color(1, 0, 0, 0.5f);
    }
    
    // Create a drawable scatter
    Scatter scatter = new Scatter(points, colors);
    scatter.setWidth(10);
 
    // Open and show chart
    Quality q = Quality.Advanced();
    IChartFactory f = new AWTChartFactory();
    Chart chart = f.newChart(q);
    chart.getScene().add(scatter);
    chart.open();
    chart.addMouse();
    chart.updateProjectionsAndRender();
    
    try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
    kmeans(points, colors, 8, scatter, chart);
    
  }

	private static void kmeans(Coord3d[] points, Color[] colors, int nrCentroids, 
			Scatter scatter, Chart chart) {
		
	    Coord3d[] centroids = new Coord3d[nrCentroids];
	    Color[] centroidColors = new Color[nrCentroids];
	    Random r = new Random();
	    r.setSeed(0);
	    
	    
	    // STEP 1 -- PLATZIERE INITIAL DIE ZENTROIDE
	    // and find cluster-colors
	    for (int i = 0; i < nrCentroids; i++) {
	    	centroids[i] = new Coord3d(r.nextFloat(), r.nextFloat(), r.nextFloat());
	    	//centroids[i] = new Coord3d(0, 0, 0);
	    	centroidColors[i] = new Color(r.nextFloat(), r.nextFloat(), r.nextFloat(), 0.5f);
	    }
		
	     
	    for (int c = 0; c < 60; c++) {
		    List<List<Integer>> clusterIndexes = new ArrayList<>();
		    for (int i = 0; i < nrCentroids; i++) {
		    	clusterIndexes.add(new ArrayList<Integer>());
		    }	    
		    
		    for (int i = 0; i < points.length; i++) {
		    	// find closest centroid
		    	int closestCentId = findClosestPoint(points[i], centroids, clusterIndexes, points.length);
		    	
		    	// assign point to cluster:
		    	clusterIndexes.get(closestCentId).add(i);
		    }
		    
		    // just for displaying: 
		    // color the different clusters that are found:
		    for (int i = 0; i < clusterIndexes.size(); i++) {
		    	for (Integer index : clusterIndexes.get(i)) {
		    		colors[index] = centroidColors[i];
		    	}
		    }
		    scatter.setColors(colors);
		    chart.updateProjectionsAndRender();
		    System.out.println("redrawn");
		    try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		    // find centers of mass for next centroids
		    for (int i = 0; i < clusterIndexes.size(); i++) {
		    	if (clusterIndexes.get(i).size() > 0) {
		    		centroids[i] = centerOfMass(clusterIndexes.get(i), points);
//		    		if (i <= 1) {
		    			System.out.println("new center: " + centroids[i].toString() + " nr points: " + clusterIndexes.get(i).size());
//		    		}
		    	}
		    }
			
		    	    	
	    }
		
	}

	private static Coord3d centerOfMass(List<Integer> list, Coord3d[] points) {
		float x = 0;
		float y = 0;
		float z = 0;
		
		for (Integer index : list) {
			x += points[index].x;
			y += points[index].y;
			z += points[index].z;
		}
		
		x = x / (float)list.size();
		y = y / (float)list.size();
		z = z / (float)list.size();
		
		return new Coord3d(x, y, z);
	}

	private static int findClosestPoint(Coord3d point, Coord3d[] centroids, List<List<Integer>> clusterIndexes, int totalNr) {
		int res = 0;
		double closestDist = Double.MAX_VALUE;
		for (int i = 0; i < centroids.length; i++) {
			
			//if (clusterIndexes.get(i).size() < (totalNr / centroids.length) * 1.1) {

				double dist = calcDistance(point, centroids[i]);
				if (dist < closestDist) {
					closestDist = dist;
					res = i;
				}
				
			//}
			
		}
		return res;
	}

	private static double calcDistance(Coord3d pointa, Coord3d pointb) {
		double dist = (pointa.x - pointb.x) * (pointa.x - pointb.x);
		dist += (pointa.y - pointb.y) * (pointa.y - pointb.y);
		dist += (pointa.z - pointb.z) * (pointa.z - pointb.z);
		return Math.sqrt(dist);
	}
}