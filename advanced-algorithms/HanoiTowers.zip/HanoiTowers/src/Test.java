
public class Test {

	
	public int[] returnAnArray() {
		
		int[] myResultArray = new int[2];
		
		return myResultArray;
		
	}
	
}
