
public class HanoiSolver {
	
	static int[] source;
	static int[] help;
	static int[] target;
	
	public static void main(String[] args) {
		System.out.println("Solving Hanoi");
		
		int size = 7;
		
		// init: 
		source = new int[size];
		help = new int[size];
		target = new int[size];
		
		// init source:
		for (int i = 0; i < source.length; i++) {
			source[i] = i + 1;
		}
		
		showTowers(source, help, target);
		
		move(size, source, help, target, false);
		//showTowers(source, help, target);
	}
	
	private static void move(int size, int[] s, int[] h, int[] t, boolean print) {
		if (print) {
			showTowers(source, help, target);
		}
		
		if (size > 0) {
			move(size - 1, s, t, h, false);
			movelastToFirst(s, t);
			move(size - 1, h, s, t, true);
		}
		
	}
	
	static public void movelastToFirst(int[] s, int[] t) {
		
		int indexFirstS = -1;
		int indexTopT = -1;
		
		for (int i = 0; i < s.length; i++) {
			if (s[i] > 0 && indexFirstS == -1) {
				indexFirstS = i;
			}
		}
		
		for (int i = 0; i < s.length; i++) {
			if (t[i] == 0) {
				indexTopT = i;
			}
		}
		
		if (indexTopT > -1 && indexFirstS > -1) {
			t[indexTopT] = s[indexFirstS];
			s[indexFirstS] = 0;
		}
		//System.out.println("indexes: " + indexFirstS + "|" + indexTopT);
	}

	static public void showTowers(int[] a, int[] b, int[] c) {
		for (int i = 0; i < a.length; i++) {
			printBrick(a[i], a.length);
			System.out.print(" ");
			printBrick(b[i], a.length);
			System.out.print(" ");
			printBrick(c[i], a.length);
			System.out.println("");
		}
		for (int i = 0; i < a.length; i++) {
			System.out.print("----");			
		}
		System.out.println("");
	}
	
	static public void printBrick(int width, int space) {
		for (int i = 0; i < width; i++) {
			System.out.print("X");
			space--;
		}
		for (int i = 0; i < space; i++) {
			System.out.print(" ");
		}
	}

}
