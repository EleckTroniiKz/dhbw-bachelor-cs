
public class Knoten {
	
	// Eigenschaft f�r uns, damit wir wissen, welcher Knoten
	// gemeint ist:
	public final String name;
	
	// Eigenschaften f�r die eigentliche Suche
	public String farbe;
	public int d;
	public Knoten pre;
	public int g;

	public int heuristik;
	
	public Knoten(String name) {
		this.name = name;
		g = 0;
	}

}
