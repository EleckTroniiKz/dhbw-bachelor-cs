import java.util.HashSet;
import java.util.Set;

public class AStar {
	
	public static void main(String[] args) {
		
		System.out.println("Hallo, ich mache A*");
		
		Knoten frank = new Knoten("Frankfurt"); 
		Knoten kaiser = new Knoten("Kaiserslautern"); 
		Knoten ludwig = new Knoten("Ludwigshafen"); 
		Knoten wuerz = new Knoten("W�rzbug");
		Knoten heilb = new Knoten("Heilbronn"); 
		Knoten karls = new Knoten("Karlsruhe"); 
		Knoten saarb = new Knoten("Saarbr�cken");
		
		GraphGewichtet graph = new GraphGewichtet();
		
		graph.alleKnoten.add(frank);
		graph.alleKnoten.add(kaiser);
		graph.alleKnoten.add(ludwig);
		graph.alleKnoten.add(wuerz);
		graph.alleKnoten.add(heilb);
		graph.alleKnoten.add(karls);
		graph.alleKnoten.add(saarb);
		
		graph.fuegeKanteHinzu(saarb, kaiser, 70);
		graph.fuegeKanteHinzu(saarb, karls, 145);
		graph.fuegeKanteHinzu(kaiser, frank, 103);
		graph.fuegeKanteHinzu(kaiser, ludwig, 53);
		graph.fuegeKanteHinzu(karls, heilb, 84);
		graph.fuegeKanteHinzu(frank, wuerz, 116);
		graph.fuegeKanteHinzu(ludwig, wuerz, 183);
		graph.fuegeKanteHinzu(heilb, wuerz, 102);
		
		initAStar(graph, saarb, wuerz);
		
		Knoten ziel = macheAStar(graph, saarb, wuerz);
		
		zeigeRueckwaertsPfad(ziel);
	}

	private static void zeigeRueckwaertsPfad(Knoten ziel) {
		
		System.out.println("Pfadelement: " + ziel.name);
		if (ziel.pre != null) {
			zeigeRueckwaertsPfad(ziel.pre);
		}
		
	}

	private static Knoten macheAStar(GraphGewichtet graph, Knoten start, Knoten ziel) {
		
		PriorityQueue openList = new PriorityQueue();
		Set<Knoten> closedList = new HashSet();
		
		openList.enqueue(start, 0);
		
		while (!openList.isEmpty()) {
			
			Knoten currentNode = openList.removeMin();
			
			if (currentNode.equals(ziel)) {
				System.out.println("PFAD GEFUNDEN !!");
				return currentNode;
			}
			
			closedList.add(currentNode);
			
			expandNode(currentNode, graph, closedList, openList);
			
		}
		
		System.out.println("Keinen Pfad gefunden !!");
		return null;
	}

	private static void expandNode(Knoten currentNode, 
			GraphGewichtet graph, Set<Knoten> closedList, PriorityQueue openList) {
		
		for (Kante kante : graph.Adj.get(currentNode.name)) {
			Knoten successor = kante.ziel;
			
			if (closedList.contains(successor)) {
				break;
			}
			
			int tentative_g = currentNode.g + kante.distanz; // c(currentNode, successor)
			
			if (openList.contains(successor) 
					&& tentative_g >= successor.g) {
				break;
			}
			
			successor.pre = currentNode; // to make path-result possible!
			successor.g = tentative_g; // tats�chliche Kosten bis zum Successor
			
			int f = tentative_g + successor.heuristik; // informiert/heuristik Greedy ! 
			
			if (openList.contains(successor)) {
				openList.updateKey(successor, f);
			} else {
				openList.enqueue(successor, f);
			}
			
		}
		
		
	}

	private static void initAStar(GraphGewichtet graph, Knoten saarb, Knoten wuerz) {
		
		graph.setzeHeuristik("Frankfurt", 96); 
		graph.setzeHeuristik("Kaiserslautern", 158); 
		graph.setzeHeuristik("Ludwigshafen", 108); 
		graph.setzeHeuristik("W�rzbug", 0);
		graph.setzeHeuristik("Heilbronn", 87); 
		graph.setzeHeuristik("Karlsruhe", 140); 
		graph.setzeHeuristik("Saarbr�cken", 222);
		
		graph.zeigeKnoten();
		
	}

}
