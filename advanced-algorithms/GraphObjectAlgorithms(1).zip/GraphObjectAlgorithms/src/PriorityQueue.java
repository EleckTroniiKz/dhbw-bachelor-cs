import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class PriorityQueue {
	
	Map<Knoten, Integer> queueMap = new HashMap<Knoten, Integer>();
	
	public void enqueue(Knoten knoten, int priority) {
		queueMap.put(knoten, priority);
	}

	public Knoten removeMin() {
		Knoten min = null;
		int minV = Integer.MAX_VALUE;
		
		for (Entry<Knoten, Integer> eintrag : queueMap.entrySet()) {
			if (eintrag.getValue() <= minV) {
				min = eintrag.getKey();
				minV = eintrag.getValue();
			}
		}
		
		queueMap.remove(min);
		
		return min;
	}
	
	public boolean isEmpty() {
		return queueMap.isEmpty();
	}
	
	public boolean contains(Knoten knoten) {
		return queueMap.containsKey(knoten);
	}
	
	public void updateKey(Knoten knoten, int newPriority) {
		queueMap.put(knoten, newPriority);
	}
}
