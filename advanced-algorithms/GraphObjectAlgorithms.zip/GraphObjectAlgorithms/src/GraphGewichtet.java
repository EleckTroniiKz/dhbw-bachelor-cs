import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GraphGewichtet {
	
	public List<Knoten> alleKnoten = new ArrayList<>();
	
	public Map<String, List<Kante>> Adj = new HashMap<>();
	
	public void fuegeKanteHinzu(Knoten von, Knoten nach, int distanz) {
		
		if (!Adj.containsKey(von.name)) {
			Adj.put(von.name, new ArrayList<>());
		}
		
		// defensive programming:
		Kante kante = new Kante();
		kante.ziel = nach;
		kante.distanz = distanz;
		Adj.get(von.name).add(kante);
		
	}

	public void zeigeKnoten() {
		System.out.println("Knoten�bersicht: ");
		for (Knoten k : alleKnoten) {
			System.out.println(" " + k.name + ": " + k.farbe + " " + k.d);
		}
		
	}
	

}
