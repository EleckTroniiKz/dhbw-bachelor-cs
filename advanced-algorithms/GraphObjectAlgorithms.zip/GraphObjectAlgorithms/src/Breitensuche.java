import java.util.List;

public class Breitensuche {
	
	public static void main(String[] args) {
		
		Graph graph = new Graph();

		// Knoten erzeugen:
		Knoten a = new Knoten(); a.name = "A";
		Knoten b = new Knoten(); b.name = "B";
		Knoten c = new Knoten(); c.name = "C";
		Knoten d = new Knoten(); d.name = "D";
		Knoten e = new Knoten(); e.name = "E";
		Knoten f = new Knoten(); f.name = "F";
		Knoten g = new Knoten(); g.name = "G";
		Knoten h = new Knoten(); h.name = "H";
		
		// Knoten zu Graph hinzuf�gen
		graph.alleKnoten.add(a);
		graph.alleKnoten.add(b);
		graph.alleKnoten.add(c);
		graph.alleKnoten.add(d);
		graph.alleKnoten.add(e);
		graph.alleKnoten.add(f);
		graph.alleKnoten.add(g);
		graph.alleKnoten.add(h);
		
		// Adjazenzlisten aufbauen
		graph.fuegeKanteHinzu(a, e);
		graph.fuegeKanteHinzu(b, a);
		graph.fuegeKanteHinzu(b, f);
		graph.fuegeKanteHinzu(f, c);
		graph.fuegeKanteHinzu(f, g);
		graph.fuegeKanteHinzu(g, c);
		graph.fuegeKanteHinzu(c, d);
		graph.fuegeKanteHinzu(g, d);
		graph.fuegeKanteHinzu(g, h);
		graph.fuegeKanteHinzu(d, h);
		
		macheBreitensuche(graph, b);
		
		zeigePfadFuer(d);
		
	}
	 
	static public void zeigePfadFuer(Knoten ziel) {
		Knoten aktuell = ziel;
		
		while (aktuell.pre != null) {
			System.out.print(aktuell.name + " ");
			aktuell = aktuell.pre;
		}
		System.out.println(aktuell.name);
	}
	
	static public void macheBreitensuche(Graph g, Knoten s) {
		
		Queue Q = initGraph(g, s);
		BFS(Q, g, s);
		
	}
	
	static public Queue initGraph(Graph g, Knoten s) {
		System.out.println("InitGraph");
		for (Knoten u : g.alleKnoten) {
			if (u != s) {
				u.farbe = "weiss";
				u.d = Integer.MAX_VALUE;
				u.pre = null;
			}
		}
		
		s.farbe = "grau";
		s.d = 0; 
		s.pre = null;
		
		Queue queue = new Queue();
		queue.enqueue(s);
	
		return queue;
	}
	
	public static void BFS(Queue Q, Graph g, Knoten s) {
		System.out.println("Suche");
		while (!Q.istLeer()) {
			Q.zeige();
			Knoten u = Q.dequeue();
			
			// Knoten aus Adj holen: 
			List<Knoten> kinder = g.Adj.get(u.name); // = G.Adj[u]
			if (kinder != null) {
				for (Knoten v : kinder) {
					if (v.farbe == "weiss") { // noch nicht besucht
						v.farbe = "grau";
						v.d = u.d + 1;
						v.pre = u;
						Q.enqueue(v);
					}
				}
			}
			u.farbe = "schwarz";
		}
		
		g.zeigeKnoten();
	}

}
