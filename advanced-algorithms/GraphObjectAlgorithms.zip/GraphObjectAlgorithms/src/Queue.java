import java.util.ArrayList;
import java.util.List;

public class Queue {
	
	public List<Knoten> knotenliste = new ArrayList<Knoten>(); // interne FIFO
	
	public boolean istLeer() {
		return knotenliste.isEmpty();
	}
	
	public void enqueue(Knoten neuerKnoten) {
		knotenliste.add(neuerKnoten);
	}
	
	public Knoten dequeue() {
		Knoten ersterKnoten = knotenliste.remove(0);
		
		return ersterKnoten;
	}

	public void zeige() {
		System.out.print("Queue: ");
		for (Knoten k : knotenliste) {
			System.out.print(k.name + " ");
		}
		System.out.println();
		
	}

	public Knoten holeKnotenmitKleinstemAbstand() {
		int minAbs = Integer.MAX_VALUE;
		Knoten resultat = null;
		
		for (Knoten k : knotenliste) {
			if (k.d <= minAbs) {
				resultat = k;
				minAbs = k.d;
			}
		}
		knotenliste.remove(resultat);
		return resultat;
	}

}
