
public class Kante {
	
	public Knoten ziel;
	public int distanz;

}
