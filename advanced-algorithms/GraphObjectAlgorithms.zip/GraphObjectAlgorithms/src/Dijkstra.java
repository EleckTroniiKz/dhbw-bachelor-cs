
public class Dijkstra {
	
	public static void main(String[] args) {
		
		System.out.println("Dijkstra");
		
		Knoten frank = new Knoten(); frank.name = "Frankfurt";
		Knoten mann = new Knoten(); mann.name = "Mannheim";
		Knoten wuer = new Knoten(); wuer.name = "W�rzburg";
		Knoten stutt = new Knoten(); stutt.name = "Stuttgart";
		Knoten karl = new Knoten(); karl.name = "Karlsruhe";
		Knoten erf = new Knoten(); erf.name = "Erfurt";
		Knoten nurn = new Knoten(); nurn.name = "N�rnberg";
		Knoten kass = new Knoten(); kass.name = "Kassel";
		Knoten aug = new Knoten(); aug.name = "Augsburg";
		Knoten mun = new Knoten(); mun.name = "M�nchen";
		
		GraphGewichtet graph = new GraphGewichtet();
		
		graph.alleKnoten.add(frank);
		graph.alleKnoten.add(mann);
		graph.alleKnoten.add(wuer);
		graph.alleKnoten.add(stutt);
		graph.alleKnoten.add(karl);
		graph.alleKnoten.add(erf);
		graph.alleKnoten.add(nurn);
		graph.alleKnoten.add(kass);
		graph.alleKnoten.add(aug);
		graph.alleKnoten.add(mun);
		
		graph.fuegeKanteHinzu(frank, mann, 85);
		graph.fuegeKanteHinzu(frank, kass, 173);
		graph.fuegeKanteHinzu(frank, wuer, 217);
		graph.fuegeKanteHinzu(mann, karl, 80);
		graph.fuegeKanteHinzu(wuer, erf, 186);
		graph.fuegeKanteHinzu(wuer, nurn, 103);
		graph.fuegeKanteHinzu(nurn, stutt, 183);
		graph.fuegeKanteHinzu(karl, aug, 250);
		graph.fuegeKanteHinzu(aug, mun, 84);
		graph.fuegeKanteHinzu(kass, mun, 502);
		graph.fuegeKanteHinzu(nurn, mun, 167);
		
		macheDijkstra(graph, mann);
		
	}
	
	static public void macheDijkstra(GraphGewichtet graph, Knoten start) {
		Queue Q = initGraph(graph, start);
		graph.zeigeKnoten();
		
		// eigentlicher Algo: 
		while (!Q.istLeer()) {
			Knoten k = Q.holeKnotenmitKleinstemAbstand();
			System.out.println("Knoten: " + k.name);
		}
		
		
	}
	
	static Queue initGraph(GraphGewichtet graph, Knoten start) {
		
		Queue queue = new Queue();
		for (Knoten k : graph.alleKnoten) {
			k.d = Integer.MAX_VALUE; // infinity
			k.pre = null; // nicht n�tig, weil Java auf null initialisiert
			queue.enqueue(k);
		}
		start.d = 0; 
		
		return queue;
	}

}
