import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Graph {
	
	public Map<String, List<Knoten>> Adj = new HashMap<>();
	
	public List<Knoten> alleKnoten = new ArrayList<>();
	
	public void fuegeKanteHinzu(Knoten von, Knoten nach) {
		
		if (!Adj.containsKey(von.name)) {
			Adj.put(von.name, new ArrayList<>());
		}
		
		// defensive programming: 
		if (!Adj.get(von.name).contains(nach)) {
			Adj.get(von.name).add(nach);
		}
		
	}

	public void zeigeKnoten() {
		System.out.println("Knoten�bersicht: ");
		for (Knoten k : alleKnoten) {
			System.out.println(" " + k.name + ": " + k.farbe + " " + k.d);
		}
		
	}

}
