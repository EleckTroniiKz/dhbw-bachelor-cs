package DrawTest;

import java.util.Random;

import org.jzy3d.chart.Chart;
import org.jzy3d.chart.factories.AWTChartFactory;
import org.jzy3d.chart.factories.AWTPainterFactory;
import org.jzy3d.chart.factories.IChartFactory;
import org.jzy3d.chart.factories.IPainterFactory;
import org.jzy3d.colors.Color;
import org.jzy3d.maths.Coord3d;
import org.jzy3d.plot3d.primitives.Scatter;
import org.jzy3d.plot3d.rendering.canvas.Quality;

import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLProfile;


public class ScatterDemoAWT  {
  public static void main(String[] args) {

    // Generate scatter data
    int size = 5000;
    float x;
    float y;
    float z;
    float a;

    Coord3d[] points = new Coord3d[size];
    Color[] colors = new Color[size];

    Random r = new Random();
    r.setSeed(0);

    for (int i = 0; i < size; i++) {
    	if (r.nextFloat() <= 0.33) {
    	  x = (r.nextFloat() - 0.5f) * 100f;
    	} else if (r.nextFloat() <= 0.33) {
    	  x = 200f + (r.nextFloat() - 0.5f) * 100f;	
    	} else {
      	  x = 400f + (r.nextFloat() - 0.5f) * 100f;	
    	}
    	
    	if (r.nextFloat() <= 0.33) {
      	  y = (r.nextFloat() - 0.5f) * 100f;
      	} else {
      	  y = 400f + (r.nextFloat() - 0.5f) * 100f;	
      	}
      
    	if (r.nextFloat() <= 0.33) {
        	  z = (r.nextFloat() - 0.5f) * 100f;
        } else {
        	  z = 400f + (r.nextFloat() - 0.5f) * 100f;	
        }
      
      points[i] = new Coord3d(x, y, z);
      a = 0.25f;
      colors[i] = new Color(1, 0, 0, 0.5f);
    }
    
    kmeans(points, colors, 12);

    // Create a drawable scatter
    Scatter scatter = new Scatter(points, colors);
    scatter.setWidth(10);

    // Open and show chart
    Quality q = Quality.Advanced();
    IChartFactory f = new AWTChartFactory();
    Chart chart = f.newChart(q);
    chart.getScene().add(scatter);
    chart.open();
    chart.addMouse();
  }

	private static void kmeans(Coord3d[] points, Color[] colors, int nrCentroids) {
		
	    Coord3d[] centroids = new Coord3d[nrCentroids];
	    Random r = new Random();
	    r.setSeed(0);
	    
	    // STEP 1 -- PLATZIERE INITIAL DIE ZENTROIDE
	    for (int i = 0; i < nrCentroids; i++) {
	    	centroids[i] = new Coord3d(r.nextFloat(), r.nextFloat(), r.nextFloat());
	    }
		
		
		
		
	}
}