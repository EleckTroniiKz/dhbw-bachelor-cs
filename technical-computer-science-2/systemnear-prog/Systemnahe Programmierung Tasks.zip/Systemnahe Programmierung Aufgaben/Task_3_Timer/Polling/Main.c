#include "Definitions.h"
#include <xc.h>

void setupTimer(void){
    TMR1CS = 1; //don't synchronize ext. clock input
    T1RUN = 1; // clock is dervied from T1 osc
    T1OSCEN = 1; //enable Timer Oscillator
    TMR1ON = 1; //Timer Enable
    TMR1 = 0x8000; // Set Timer Load Value
    LATB = 0;
}

void main(void) {
    
    setupTimer();
    while(1) {
        Nop();
        if (PIR1bits.TMR1IF) {
            PIR1bits.TMR1IF = 0; // Set TR1 Interrupt Flag
            TMR1 = 0x8000; // Resetting Timer Load Value
            LATBbits.LATB0 = !LATBbits.LATB0;
            Nop();
        }
    }
    
    return;
}