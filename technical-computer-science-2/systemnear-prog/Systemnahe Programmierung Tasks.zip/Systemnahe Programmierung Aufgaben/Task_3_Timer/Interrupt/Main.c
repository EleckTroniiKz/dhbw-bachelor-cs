#include "Definitions.h"
#include <xc.h>

void resetInterrupt(void) {
    TMR1 = 65450; //set Timer Load Val.
    LATBbits.LATB0 = !LATBbits.LATB0;
    return;
}

//Interrupt function, which is called when Interrupt trigered
void __interrupt(high_priority) TimerOneInterrupt(void){
    PIR1bits.TMR1IF = 0;
    reloadInterrupt();
    
    return;
}

void setupInterruptAndTimer(void){
    TRISBbits.RB0 = 0; //setting RB0 into Output pin
    INTCONbits.GIE = 1; // Enable Interrupt (gen)
    INTCONbits.PEIE = 1; // Enable all Peripherial Inputs
    PIE1bits.TMR1IE = 1; // Enable Timer-Interrupt
    TMR1ON = 1; // Enable Timer
    LATB = 0;
}


void main(void) {
    setupInterruptAndTimer();
    resetInterrupt();
    
    while(1) {
        Nop();
    }
    
    return;
}