#include "Definitions.h"
#include <xc.h>

void timerReset(void) {
    TMR1ON = 0; // Timer disable
    TMR1 = 65467; // set Timer Load Value 

    LATBbits.LATB0 = !LATBbits.LATB0;
    TMR1ON = 1; // Timer enable
}

void main(void) {
    TRISBbits.RB0 = 0; //Port B Data Direction Register; setting RB0 into Output pin
    LATB = 0;
    timerReset();

    while(1) {
        //check for timer overflow
        if (TMR1IF == 1){
            TMR1IF = 0;
            timerReset();
        }
    }
    return; //convention -> nothing is done here
}