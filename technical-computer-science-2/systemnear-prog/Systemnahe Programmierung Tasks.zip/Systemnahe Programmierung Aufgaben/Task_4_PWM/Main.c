
#include "Definitions.h"
#include <xc.h>

void preparePWM(void) {
    TRISCbits.RC2 = 0;

    //Timer Config
    T2CONbits.T2CKPS = 0b01; //prescale set
    T2CONbits.T2OUTPS = 0b0; //postscale output bits
    T2CONbits.TMR2ON = 1; //Enable Timer
    PR2 = 99; //PWM period set

    // CCP1 module config
    CCP1CONbits.CCP1M = 0b1100; //PWM mode to 11xx
    CCPR1L = 0b00101000; //duty cycle set
    CCP1CONbits.DC1B = 0b00; //Duty Cycle Bit
}

void main(void) {
    preparePWM();
    while(1) {
        Nop();
    }

    return;
}