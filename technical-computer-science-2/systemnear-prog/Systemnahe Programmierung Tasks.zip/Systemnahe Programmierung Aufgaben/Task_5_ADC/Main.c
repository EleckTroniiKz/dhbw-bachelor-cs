
#include "mcc_generated_files/mcc.h" 

void main(void)
{
    SYSTEM_Initialize(); //MCC generated

    TRISA = 0x00; //set all Bits to output (only 4 needed, but this is easier)

    while (1) {
      
      // set all LED Bits to 0
      LATAbits.LATA4 = 0;
      LATAbits.LATA5 = 0;
      LATAbits.LATA6 = 0;
      LATAbits.LATA7 = 0;

      int value = ADCC_GetSingleConversion(RA0); //get ADC value 

      // check value and set LED_bits accordingly
      if(value>512){
          LATAbits.LATA4 = 1;
          value = value-512;
      }  if (value>256){
          LATAbits.LATA5 = 1;
          value = value-256;
      }  if (value>128){
          LATAbits.LATA6 = 1;
          value = value-128;
      }  if (value>64){
          LATAbits.LATA7 = 1;
          value = value-64;
      }
    }
  return;   
}
