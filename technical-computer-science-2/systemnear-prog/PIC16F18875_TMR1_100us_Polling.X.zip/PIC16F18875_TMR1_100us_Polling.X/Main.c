/*
-------------------------------------------------------------------
File:		Main.c
Title: 		Timing Demo using Timer1
Controller:	PIC16F18875
Frequency:	32 MHz, internal osc
Board:      Curiosity Board HPC
            Simulation also possible
MPLAB X:    6.05
XC8:        2.40
Version:	1.0
Date:		25.11.2022
Author:		Aurel GONTEAN, aurel.gontean@upt.ro
-------------------------------------------------------------------
Revision history

 - Ver 1.0, 25.11.2022, Author: Aurel GONTEAN
 
-------------------------------------------------------------------
Uses:

-------------------------------------------------------------------
Description: Fosc = 32 MHz so Fcy = 8 MHz and Tcy = 128 ns
The counter must count 100us/125 = 800 clock periods
-------------------------------------------------------------------
*/

#include "Definitions.h"

void main (void){

TRISB = 0;					// PORTB = Output
LATB = 0;                   // Clear PortB
ANSELBbits.ANSB0 = 0;      //Make RB0 digital

// Configure Timer1 
T1CLKbits.CS = 0b0001;      // Clock Select bits = Fosc (32 MHz))

T1CONbits.CKPS = 0b00;      // Prescale 1:1
T1CONbits.RD16 = 1;         // All 16 bits of Timer1 can be read simultaneously
                            // (TMR1H is buffered)
T1CONbits.ON = 1;           // Enables Timer1
        
T1GCONbits.GE = 0;          // If ON = 1: Timer1 is always counting
        
TMR1 = 0xFFFF - 800;        // Write initial value to TMR1
                            // 184 instead of 200 is due to the additional code
                            // executed meanwhile. It is fine tuned
NOP();						// during Debug

while (1){
   	NOP();

	NOP();
    NOP();
	NOP();
    NOP();
	NOP();
    NOP();
	NOP();
    NOP();
	NOP();
    NOP();
    
	if (PIR4bits.TMR1IF){                    // ? Timer1 Flagged Overflow
		PIR4bits.TMR1IF = 0;                 // clear interrupt flag
        TMR1 = 0xFFFF - 800;                 // again 184 via fine tuning
        PORTBbits.RB0 = !PORTBbits.RB0;    // toggle RB0
		}
	}

T1CONbits.ON = 0;           // Never gets here; Stops TMR1               
}