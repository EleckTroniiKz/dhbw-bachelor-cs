/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F18875
        Driver Version    :  2.00
*/

#include "mcc_generated_files/mcc.h"
#include <math.h>

void main(void) {
    // initialize the device
    SYSTEM_Initialize();

 	while (1) {
		unsigned char chrCnt;
		float fltSine;

		NOP();
		for (chrCnt = 0 ; chrCnt < 250; chrCnt++) {
			fltSine = sin(chrCnt);
			}					// Delay 1.2Meg TCy = 241 ms@20 MHz

		NOP();
		for (chrCnt = 0 ; chrCnt < 250; chrCnt++) {
			fltSine = sin(chrCnt);
			} 					// Delay 1.2Meg TCy = 241 ms@20 MHz
		}

    }
