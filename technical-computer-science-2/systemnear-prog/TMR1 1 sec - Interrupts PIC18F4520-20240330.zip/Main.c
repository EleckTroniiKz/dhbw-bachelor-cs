/*
-------------------------------------------------------------------
File:		Main.c
Title: 		Get 1 sec Ticks via Interrupts
Hardware:	APIC and PICDEM2 Boards
			Simulation also possible
Controller:	PIC18F4520
Frequency:	4 MHz (PLL disabled)
Compiler:   XC8 ver. 2.10
MPLAB X     5.35           
Version:	1.1
Date:		28.01.2021
Author:		Aurel GONTEAN, aurel.gontean@upt.ro
-------------------------------------------------------------------
Revision history

 - Ver 1.0, 07.11.2016, Author: Aurel GONTEAN
 - Ver 1.1, 09.05.2020, Author: Aurel GONTEAN

-------------------------------------------------------------------
Description: 
 Blink a LED at 1 Hz. 
-------------------------------------------------------------------
*/


#include "Definitions.h"

void __interrupt(high_priority) TMR1Int(void)
{
if (PIR1bits.TMR1IF && PIE1bits.TMR1IE){ // check for TMR1 overflow
	PIR1bits.TMR1IF = 0;                 // clear interrupt flag
    TMR1 = 0x8000;                       // xxx via fine tuning
    LATBbits.LATB0 = !LATBbits.LATB0;    // toggle RB0
    }
return;
}

void main(void) {
    T1CONbits.RD16 = 1;         // Enables register read/write of TImer1 in one 16-bit operation
    T1CONbits.T1RUN = 1;        // Device clock is derived from Timer1 oscillator
    T1CONbits.T1CKPS = 0b00;    // 1:1 Prescaler 
    T1CONbits.T1OSCEN = 1;      // Timer1 oscillator is enabled
    T1CONbits.T1SYNC = 1;
    T1CONbits.TMR1CS = 1;       // External clock from pin RC0/T1OSO/T13CKI (on the rising edge)
    T1CONbits.TMR1ON = 1;       // Start TMR1

    TRISBbits.RB0 = 0;

// Configure Interrupt via INTCON    
    PIE1bits.TMR1IE = 1;		// enable TMR1 Interrupts (TMR1IE)
    INTCONbits.GIE  = 1;		// enable global interrupts (GIE)
    INTCONbits.PEIE = 1;        // enable peripheral interrupts (PEIE)

    TMR1 = 0x8000;              // Initialize TMR1 for a 1s Interrupt

    while (1){  
        Nop();
        
    }
    return;
}    


