/*
-------------------------------------------------------------------
File:		PWM.c
Title: 		PWM Demo using
Hardware:
Controller:	PIC18F4520
Frequency:	16 MHz (4 x PLL enabled)
Board:      APIC
            Simulation is also possible
Versions:
Code:       1.2
XC8:        2.0
MPLAB X:    5.05
Date:		15.03.2019 15:00
Author:		Aurel GONTEAN, aurel.gontean@upt.ro
-------------------------------------------------------------------
Revision history
 - Ver 1.0, 22.11.2015, Author: Aurel GONTEAN
 - Ver 1.1, 7.11.2016 - minor updates. MPLAB X version 3.40 & XC8 1.38
 - Ver 1.2 23.10.2018 - MPLAB X version 5.05 & XC8 2.0
                        as Microchip does not any longer support them,
                        no more legacy peripheral libraries used.
                        Instead, direct register manipulation is used
-------------------------------------------------------------------
Description: PWM output is obtained on CCP1 pin.
* PWM period     = [(period ) + 1] x 4 x Tosc x TMR2 prescaler
*
* PWM Duty cycle = (DCx<9:0>) x Tosc
*
* Resolution (bits) = log(Fosc/Fpwm) / log(2) *
*
* 10kHz = 100 us PWM Period; 40% Duty Cycle => Ton = 40us
* Fosc = 16 MHz; Tosc  = 62.5 ns
* For a 1:4 Prescaler, 100us = (PR2+1) x 0.25us *4 = PR2 +1
* So, PR2 = 99
*
* DC = 40us, so 40 us = CCP x 0.250 us, ie CCP = 160 (0b0010100000)
* (0xA0)
*
-------------------------------------------------------------------
*/

#include "Definitions.h"

void main(void) {

TRISCbits.RC2 = 0;

// Configure Timer2
T2CONbits.T2CKPS  = 0b01;   // Prescale Select bits (Prescaler is 1:4)
T2CONbits.T2OUTPS = 0b0000; // Output Postscale Select bits (Postscale is 1:1)
T2CONbits.TMR2ON  = 1;      // Start Timer 2
PR2 = 99;                   // see above

// Configure the CCP1 module
CCP1CONbits.CCP1M = 0b1100; // Select PWM mode

// -----set DC - the duty cycle----
CCPR1L = 0b00101000;
CCP1CONbits.DC1B = 0b00;

while(1){
    Nop();
    }
    return;
}

