/*
-------------------------------------------------------------------
File:		Main.c
Title: 		Timing Demo using Timer1 and Interrupts
Hardware:	
Controller:	PIC18F4520
Frequency:	16 MHz (4 x PLL enabled)
Board:      PICDem2+
            Simulation is also possible
Versions:
Code:       1.2
XC8:        2.0
MPLAB X:    5.05
Date:		15.03.2019 15:15
Author:		Aurel GONTEAN, aurel.gontean@upt.ro
-------------------------------------------------------------------
Revision history
 - Ver 1.0, 22.11.2015, Author: Aurel GONTEAN
 - Ver 1.1, 7.11.2016 - minor updates. MPLAB X version 3.40 & XC8 1.38
 - Ver 1.2 23.10.2018 - MPLAB X version 5.05 & XC8 2.0
                        as Microchip does not any longer support them, 
                        no more legacy peripheral libraries used.
                        Instead, direct register manipulation is used
 _ Ver 1.4 29.04.2020 - MPLAB X version 5.35 & XC8 Ver 2.10
-------------------------------------------------------------------
Description: generates exact 100us pulses at RB0 (and RB3, optional).
For a 16 MHz (= Fosc) CPU clock, Tcy = 250 ns. 
The timer must count 100us = 100,000ns/250ns = 400 TCy periods
1/Tcy (Fosc/4) is the clock source for Timer1 (Prescaler is 1:1)
The simulator must be set for Tcy = 4 MHz (by default is 1 MHz)
-------------------------------------------------------------------
*/

#include "Definitions.h"    // CPU config

char TimeOut;				// Flag - indicates Tmr1 Overflow

//void interrupt TimerOverflow(void)
void __interrupt(high_priority) TMR1Int(void)
{
if (PIR1bits.TMR1IF && PIE1bits.TMR1IE){ // check for TMR1 overflow
	PIR1bits.TMR1IF = 0;                 // clear interrupt flag
    TMR1 = 0xFFFF - 377;                 // 377 via fine tuning
    LATBbits.LATB0 = !LATBbits.LATB0;    // toggle RB0
    TimeOut = 1;                         // Timing reached
    }
return;
}

void main (void){

// Configure Interrupt via INTCON    
PIE1bits.TMR1IE = 1;		// enable TMR1 Interrupts (TMR1IE)
INTCONbits.GIE  = 1;		// enable global interrupts (GIE)
INTCONbits.PEIE = 1;        // enable peripheral interrupts (PEIE)

// Configure PortB
TRISB = 0;					// PORTB = Output
LATB = 0;                   // Clear PortB

// Configure Timer1 via T1CON
T1CONbits.RD16     = 1;     // Enables register read/write of TMR1 in one 16-bit operation
T1CONbits.T1RUN    = 0;     // Device clock is derived from another source
T1CONbits.T1CKPS = 0b00;    // 1:1 Prescaler
T1CONbits.T1OSCEN  = 0;     // Timer1 oscillator is shut off
T1CONbits.nT1SYNC  = 0;     // When TMR1CS = 0, this bit is ignored.
T1CONbits.TMR1CS   = 0;     // Internal clock (FOSC/4)
T1CONbits.TMR1ON   = 1;     // Start (enable) TMR1 to run

TimeOut = 0;                // Clear Flag

TMR1 = 0xFFFF - 334;        // Write initial value to TMR1
                            // 334 instead of 400 is due to the additional code
                            // executed meanwhile. It is fine tuned
Nop();						// during Debug

while (1){
	Nop();
	if (TimeOut){                               // ? Timer1 Flagged Overflow
		LATBbits.LATB3 = !LATBbits.LATB3;       // Toggle RB3
		TimeOut = 0;                            // Clear TimeOut Flag
		}
	}

T1CONbits.TMR1ON = 0;        // Never gets here; Stops TMR1               
}
