#include "mcc.h"

void main(void)
{
    // initialize the device
    SYSTEM_Initialize();

    while (1)
        {
        NOP();
        // Add your application code
        }
}
