 /**
   PWM6 Generated Driver File
 
   @File Name
     pwm6.c
 
   @Summary
     This is the generated driver implementation file for the PWM6 driver using PIC10 / PIC12 / PIC16 / PIC18 MCUs
 
   @Description
     This source file provides implementations for driver APIs for PWM6.
     Generation Information :
         Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
         Device            :  PIC16F18875
         Driver Version    :  2.01
     The generated drivers are tested against the following:
         Compiler          :  XC8 2.36 and above or later
         MPLAB             :  MPLAB X 6.00
 */ 

 #include <xc.h>
 #include "pwm6.h"

 void PWM6_Initialize(void) {
PWM6CON = 0x80;             // PWM6POL active_hi; PWM6EN enabled;
PWM6DCH = 0x09;             // DC 9;   
PWM6DCL = 0xC0;             // DC 3; 
CCPTMRS1bits.P6TSEL = 1;    // Select timer
}

 void PWM6_LoadDutyValue(uint16_t dutyValue) {
PWM6DCH = (dutyValue & 0x03FC)>>2; // Write 8 MSBs of PWM duty cycle in PWMDCH
PWM6DCL = (dutyValue & 0x0003)<<6; // Write 2 LSBs of PWM duty cycle in PWMDCL
}

