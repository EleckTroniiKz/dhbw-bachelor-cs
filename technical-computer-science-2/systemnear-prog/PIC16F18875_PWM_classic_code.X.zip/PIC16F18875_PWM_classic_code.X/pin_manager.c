/**
  Generated Pin Manager File

  File Name:
    pin_manager.c

  Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for pin APIs for all pins selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F18875
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.36 and above
        MPLAB             :  MPLAB X 6.00

    Copyright (c) 2013 - 2015 released Microchip Technology Inc.  All rights reserved.
*/

#include "pin_manager.h"

void PIN_MANAGER_Initialize(void) {
// LATx registers
    LATE = 0x00;
    LATD = 0x00;
    LATA = 0x00;
    LATB = 0x00;
    LATC = 0x00;

// TRISx registers
    TRISE = 0x07;       // all inputs (PORTE is incomplete)
    TRISA = 0xFF;       // all inputs
    TRISB = 0xFF;       // all inputs
    TRISC = 0xFF;       // all inputs
    TRISD = 0xFE;       // RD0 output, RD1 - RD7 = input

// ANSELx registers
    ANSELD = 0xFE;      // RD0 = digital, RD1 - RD7 = analog
    ANSELC = 0xFF;      // all analog
    ANSELB = 0xFF;      // all analog
    ANSELE = 0x07;      // all analog (PORTE is incomplete)
    ANSELA = 0xFF;      // all analog

// WPUx registers
    WPUD = 0x00;        // all Weak pull-up resistors disabled
    WPUE = 0x00;        // all Weak pull-up resistors disabled
    WPUB = 0x00;        // all Weak pull-up resistors disabled
    WPUA = 0x00;        // all Weak pull-up resistors disabled
    WPUC = 0x00;        // all Weak pull-up resistors disabled

// ODx registers
    ODCONE = 0x00;      // all open drain disabled (work as normal push-pull)
    ODCONA = 0x00;      // all open drain disabled (work as normal push-pull)
    ODCONB = 0x00;      // all open drain disabled (work as normal push-pull)
    ODCONC = 0x00;      // all open drain disabled (work as normal push-pull)
    ODCOND = 0x00;      // all open drain disabled (work as normal push-pull)

// SLRCONx registers
    SLRCONA = 0xFF;     // slew rate control disabled (maximum speed @ all pins)
    SLRCONB = 0xFF;     // slew rate control disabled (maximum speed @ all pins)
    SLRCONC = 0xFF;     // slew rate control disabled (maximum speed @ all pins)
    SLRCOND = 0xFF;     // slew rate control disabled (maximum speed @ all pins)
    SLRCONE = 0x07;     // slew rate control disabled (maximum speed @ all pins)

// INLVLx registers     // Port Input Level COntrol Register (ST or TTL)
    INLVLA = 0xFF;      // ST inputs used for PORT reads and interrupt-on-change
    INLVLB = 0xFF;      // ST inputs used for PORT reads and interrupt-on-change
    INLVLC = 0xFF;      // ST inputs used for PORT reads and interrupt-on-change
    INLVLD = 0xFF;      // ST inputs used for PORT reads and interrupt-on-change
    INLVLE = 0x07;      // ST inputs used for PORT reads and interrupt-on-change
	
    RD0PPS = 0x0E;      // PWM6:PWM6OUT (=0E) is routed to RD0 pin via PPS;    
}
  
void PIN_MANAGER_IOC(void)  // Interrupt on change
{   
}

