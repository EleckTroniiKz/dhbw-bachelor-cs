/*
 * File:   Main.c
 * Author: Aurel
 *
 * Created on 18 octombrie 2018, 17:25
 */


#include "Definitions.h"

void main(void) {
    TRISAbits.RA0 = 1;          // RA0 = AN0 is input
    TRISB = 0;                  // PORTB is Output
    TRISD = 0;
    LATB  = 0x00;               // All LEDs are OFF
    
    
    ADCON0bits.CHS = 0b0000;    // Select AN0 as input for ADC
    ADCON0bits.GO  = 0;    // no ADC conversion yet
    ADCON0bits.ADON = 1;        // ADC Module is turned ON
    ADCON1bits.VCFG = 0b00;     // Vss and Vdd are the voltage references
    ADCON1bits.PCFG = 0b1110;   // AN0 selected as analog, other ANx inputs as digital
    ADCON2bits.ADFM = 1;        // The Result is right justified
    ADCON2bits.ACQT = 0b010;    // 4 Tad
    ADCON2bits.ADCS = 0b100;    // 4 Tosc

    while(1){    
        __delay_us(10);         // wait
        ADCON0bits.GO = 1;      // Start ADC conversion
        while(!ADCON0bits.GO);  // Wait for the conversion to complete
        Nop();
        PIR1bits.ADIF = 0;      // Clear ADIF Flag
        LATB = ADRES/4;         // Display the ADC conversion result on LEDs 
        LATD = ADRES/4;
        Nop();
        __delay_ms(10);
        }
    return;
}
