/*
-------------------------------------------------------------------
File:		Main.c
Title: 		Timing Demo using Timer1
Hardware:	
			
Controller:	PIC18F4520
Frequency:	16 MHz (4 x PLL enabled)
Board:      PICDem2+ or APIC
            Simulation also possible
Version:	1.0
Date:		22.11.2019
Author:		Aurel GONTEAN, aurel.gontean@upt.ro
-------------------------------------------------------------------
Revision history

 - Ver 1.0, 22.11.2015, Author: Aurel GONTEAN
 - Ver 1.1, 27.02.2015, MPLAB X & XC8 Migration
-------------------------------------------------------------------
Uses:

-------------------------------------------------------------------
Description: Fosc= 16 MHz so Fcy = 4 MHz and Tcy = 250 ns
The counter must count 100us/250 = 400 clock periods
-------------------------------------------------------------------
*/

#include "Definitions.h"

void main (void){

TRISB = 0;					// PORTB = Output
LATB = 0;                   // Clear PortB

// Configure Timer1 via T1CON
T1CONbits.RD16     = 1;     // Enables register read/write of TMR1 
                            // in one 16-bit operation
T1CONbits.T1RUN    = 0;     // Device clock is derived from another source
T1CONbits.T1CKPS   = 0b00;  // 1:1 Prescaler
T1CONbits.T1OSCEN  = 0;     // Timer1 oscillator is shut off
T1CONbits.nT1SYNC  = 0;     // When TMR1CS = 0, this bit is ignored.
T1CONbits.TMR1CS   = 0;     // Internal clock (FOSC/4)
T1CONbits.TMR1ON   = 1;     // Start (enable) TMR1 to run

TMR1 = 0xFFFF - 334;        // Write initial value to TMR1
                            // 334 instead of 400 is due to the additional code
                            // executed meanwhile. It is fine tuned
Nop();						// during Debug

while (1){
	Nop();
	if (PIR1bits.TMR1IF){                    // ? Timer1 Flagged Overflow
		PIR1bits.TMR1IF = 0;                 // clear interrupt flag
        TMR1 = 0xFFFF - 390;                 // again 385 via fine tuning
        LATBbits.LATB0 = !LATBbits.LATB0;    // toggle RB0
		}
	}

T1CONbits.TMR1ON = 0;        // Never gets here; Stops TMR1               
}