/*
-------------------------------------------------------------------
File:		Main.c
Title: 		Get 1 sec Ticks via Polling
Hardware:	Curiosity HPC Board
			Simulation also possible
Controller:	PIC16F18875
Frequency:	32MHz (internal Oscillator)
Compiler:   XC8 ver. 2.40
MPLAB X     6.05           
Version:	1.0
Date:		25.11.2022
Author:		Aurel GONTEAN, aurel.gontean@upt.ro
-------------------------------------------------------------------
Revision history
 - Ver 1.0, 25.11.2022, Author: Aurel GONTEAN
-------------------------------------------------------------------
Description: 
 Blink a LED at 1 Hz. 
-------------------------------------------------------------------
*/

#include "Definitions.h" 

void main(void) {
    TRISB0 = 0;       // Make RB0 = Output
    LATB = 0;
    ANSELBbits.ANSB0 = 0;   //Make RB0 digital
    
    while(1){
       LATBbits.LATB0 = 1;   // Turn On LED
       __delay_ms(250);
        NOP();
        
        LATBbits.LATB0 = 0;   // Turn Off LED
        __delay_ms(750);
//        NOP();
    }
    return;
}

