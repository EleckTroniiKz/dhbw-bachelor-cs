import java.util.concurrent.Semaphore;

public class SemaphorenDemo extends Thread {
	
  static public void main (String args[])
         throws InterruptedException
  {
    Semaphore s;
    s  = new Semaphore (1); // Bin�re Semaphore
    Thread threads[] = new Thread[3];
    for (int i = 0; i < threads.length; i++)
      threads[i] = new TestThread (s); // Threads erzeugen
    for (int i = 0; i < threads.length; i++)
      threads[i].start (); // Threads starten
    for (int i = 0; i < threads.length; i++)
      threads[i].join (); //auf Threads warten bis sie enden.
    System.out.println("Programmende");
  } // main
}
