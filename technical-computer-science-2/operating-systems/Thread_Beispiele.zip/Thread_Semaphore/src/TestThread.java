// File  : SemaphorenDemo.java
// Die klassischen Semaphoren in Java.

import java.util.concurrent.*;

class TestThread extends Thread {
  private Semaphore s;
  
 // Methoden
  public TestThread (Semaphore s) {
    this.s = s;
  } // Konstruktor
// Schlafen legen
  public void randomSleep (int time) {
    try {
      sleep (Math.round (time*Math.random ()));
    }
    catch (InterruptedException e) {
      System.out.println (e);
    }
  }
// run-Methode
  
  public void run () {
    try {
      for (int i = 0; i < 5; i++) {
        s.acquire ();
        System.out.println ("Semaphore belegt " + this);
        randomSleep (500);
        System.out.println ("Semaphore frei   " + this);
        s.release ();
        randomSleep (100);
      }    
    } catch (InterruptedException e) {
      e.printStackTrace (System.err);
      System.exit (1);
    }
  }
}

