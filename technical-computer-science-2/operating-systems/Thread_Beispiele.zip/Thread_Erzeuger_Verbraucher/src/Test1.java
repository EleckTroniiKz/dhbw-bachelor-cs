// Programm zum Testen von Verbraucher und Erzeuger
// Dieses Programm kann einen Erzeuger, aber mehrere Verbraucher bedienen
// ArrayBlockingQueue passt auf die Grenzen des Arrays auf.
//---------------------------------------
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

// Klasse zum Testen der Pipe
public class Test1 {
	
	
	public static void main(String arg[]) throws InterruptedException
	{
		int N_Verbraucher = 3; // Anzahl der Verbraucher
		Thread p[] = new Thread [N_Verbraucher+1];
		BlockingQueue <Integer> puffer = new ArrayBlockingQueue <Integer> (100);
	// Threads erzeugen
	    p[0] = new Thread(new Erzeuger(puffer)); // 1 Thread f�r den Erzeuger
	    for(int i = 1; i < N_Verbraucher+1; i++) 
	    	p[i]= new Thread(new Verbraucher(puffer)); //Erstellen der N_Verbraucher-Threads
	    for(int i = 0; i < N_Verbraucher+1; i++) p[i].start(); //Starten aller Threads
	    for(int i = 0; i < N_Verbraucher+1; i++){
	    try {
		      p[i].join (); // Warten auf das Ende der Threads
		      } catch (Exception e) {
		        System.err.println (e);
		      } // try-Block
		  } // For-Schleife
		    System.out.println("Programmende");
	}
}