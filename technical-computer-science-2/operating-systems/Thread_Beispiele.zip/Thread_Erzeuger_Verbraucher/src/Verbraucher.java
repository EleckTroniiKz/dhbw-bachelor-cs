// der Verbraucher entnimmt aus der BlockingQueue
// falls die Queue leer ist wird der Verbraucher automatisch blockiert
//---------------
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

public class Verbraucher implements Runnable{
	private final BlockingQueue <Integer> puffer;
	 public Verbraucher(BlockingQueue <Integer> puffer){
		 this.puffer = puffer;
	 }
	 public void run(){
		float wartezeit = 150;
		try {
			while(true) {
				int ausgabe = puffer.take();
				if(ausgabe == -1){
					puffer.put(-1);
					System.out.println(toString() + " terminiert");
					return;
				}
				System.out.println(toString() + " entnimmt: " + ausgabe);
				TimeUnit.MILLISECONDS.sleep(Math.round(wartezeit*Math.random()));
			}
		} catch (InterruptedException e){
			 e.printStackTrace(System.err);
		} // try-Block
	 } // run-Block

}
