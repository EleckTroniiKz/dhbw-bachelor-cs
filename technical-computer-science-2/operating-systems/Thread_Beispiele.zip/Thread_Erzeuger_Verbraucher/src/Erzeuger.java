// Erzeuger produziert Daten und liefert Sie an den Verbraucher
// das Ende der Eingabe wird durch -1 angezeigt
// mit TimeUnit wird die Eingabe verz�gert.
// BlockingQueue verhindert, dass man nicht �ber die Grenzen hinausschreibt. 
//------
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

public class Erzeuger implements Runnable{
 private final BlockingQueue <Integer> puffer;
 public Erzeuger(BlockingQueue <Integer> puffer){
	 this.puffer = puffer;
 }
 public void run(){
	 long wartezeit = 20;
	 for(int i = 0; i < 20; i++){
		 try {
			 puffer.put(i);
			 System.out.println("Erzeuger speichert: " + i);
			 TimeUnit.MILLISECONDS.sleep(wartezeit);	 
		 } catch (InterruptedException e){
			 e.printStackTrace(System.err);
		 } 
	 }// for-Schleife
	try {
		 int ende = -1;
		 puffer.put(ende);
		 System.out.println("Ereuger beendet die �bertragung: " + ende);
		 TimeUnit.MILLISECONDS.sleep(wartezeit);	 
		 } catch (InterruptedException e){
			 e.printStackTrace(System.err);
		 }
 	}
}
