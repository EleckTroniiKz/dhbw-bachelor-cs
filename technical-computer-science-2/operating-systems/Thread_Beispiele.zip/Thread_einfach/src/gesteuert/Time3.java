package gesteuert;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Time3 extends Thread {
	private boolean running = true;
	public void run() {
		GregorianCalendar d;
// Vorsicht Endlosschleife
		while( running) {
			d = new GregorianCalendar();
			System.out.println( 
					d.get(Calendar.HOUR_OF_DAY) +":" + 
					d.get(Calendar.MINUTE) + ":" + 
					d.get(Calendar.SECOND));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("Interrupted!");
				return;
				
			}
		} // While-Block
	} //run
	public void beenden() {
		running = false;
		System.out.println("Thread wird beendet");
	}
}

