package gesteuert;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Uhr3 {
		public static void main(String[] args) throws IOException
		{
			String kommando;
			Time3 t = new Time3();
			t.start();
			// Warten auf Benutzereingabe. Terminieren mit exit
			while(true) {
				BufferedReader reader = new BufferedReader(new InputStreamReader (System.in));
				try {
				kommando = reader.readLine();
				} catch( IOException e ) {
					System.out.println("Eingabefehler");
					break;
				}
				if(kommando.equals("exit")) break; // Loop terminieren
			} // while
			t.beenden(); // Aufruf der Methode beenden
		} // main
	} // Klasse
