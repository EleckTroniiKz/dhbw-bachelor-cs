package interrupted;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Time2 implements Runnable {
	public void run() {
		GregorianCalendar d;
// Vorsicht Endlosschleife
		while( true) {
			d = new GregorianCalendar();
			System.out.println( 
					d.get(Calendar.HOUR_OF_DAY) +":" + 
					d.get(Calendar.MINUTE) + ":" + 
					d.get(Calendar.SECOND));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("Interrupted!");
				System.out.println("Threadende");
				return;
			} //try-Block
		} // While-Block
	} // run
}

