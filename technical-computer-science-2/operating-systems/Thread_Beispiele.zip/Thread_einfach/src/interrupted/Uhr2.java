package interrupted;
import java.io.*;

public class Uhr2 {
		public static void main(String[] args) 
		{
			String kommando;
			Thread t = new Thread(new Time2());
			t.start();
			// Warten auf Benutzereingabe. Terminieren mit exit
			while(true) {
				BufferedReader reader = new BufferedReader(new InputStreamReader (System.in));
				try {
				kommando = reader.readLine();
				} catch( IOException e ) {
					System.out.println("Eingabefehler");
					break;
				} // try-Block
				if(kommando.equals("exit")) break; // Loop terminieren
			} // while
			t.interrupt(); // Thread ein Interrupt schicken
		} // main
	} // Klasse
