package vererben;

public class Uhr {
	public static void main(String[] args) 
	{
		Time t = new Time();
		t.start();
	}
}
