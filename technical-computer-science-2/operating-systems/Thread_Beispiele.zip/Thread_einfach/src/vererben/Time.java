package vererben;
import java.util.*;

public class Time extends Thread{
	public void run() {
		GregorianCalendar d;
		int i = 0;
		while( i < 20) {
			d = new GregorianCalendar();
			System.out.println( 
					d.get(Calendar.HOUR_OF_DAY) +":" + 
					d.get(Calendar.MINUTE) + ":" + 
					d.get(Calendar.SECOND));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
			} // try-Block
			i++;
		} // while-Block
		System.out.println("Threadende");
	} // run
} // Klasse
