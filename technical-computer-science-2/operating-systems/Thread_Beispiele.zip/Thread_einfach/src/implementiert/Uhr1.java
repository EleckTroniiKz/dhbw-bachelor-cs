package implementiert;

public class Uhr1 {
		public static void main(String[] args) 
		{
			Thread t = new Thread(new Time1());
			//Thread t1 = new Thread(new Time1());
			t.start();
			//t1.start();
		}
	}