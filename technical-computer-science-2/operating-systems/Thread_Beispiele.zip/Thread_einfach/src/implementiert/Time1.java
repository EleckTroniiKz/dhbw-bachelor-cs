package implementiert;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Time1 implements Runnable {
	public void run() {
		GregorianCalendar d;
		int i = 0;
		while( i < 20) { // Block wird auf 20 Ausgaben beschr�nkt
			d = new GregorianCalendar();
			System.out.println( 
					d.get(Calendar.HOUR_OF_DAY) +":" + 
					d.get(Calendar.MINUTE) + ":" + 
					d.get(Calendar.SECOND));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// da in diesem Programm nie ein Exception auftritt, br�uchte man keine Behandlung
				System.out.println("Oweija ein Interrupt!");
				return;
			} //try-Block
			i++;
		} // While-Block
		System.out.println("Threadende");
	} // run
}
