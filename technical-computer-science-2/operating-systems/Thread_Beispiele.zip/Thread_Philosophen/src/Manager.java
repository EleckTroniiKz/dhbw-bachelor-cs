
class Manager {
  public final static int N = 5;        // fuenf Philosophen
  private static int phils[];           // Zust�nde der Betriebsmittel
  private final static int NOTHING = 0;
  private final static int EATING = 1;

  static {
    phils = new int [N];
    for (int i = 0; i < N; i++)
      phils[i] = NOTHING; // Eigentlich der Defaultwert
  }
//Methoden der Klasse Manager
  private int left (int i) { return (i+N-1) % N; } // Linker Nachbar
  private int right (int i) { return (i+1) % N; }  // Rechter Nachbar 
//----------------------------------------------
  synchronized public void TakeForks (int no) {
    while (phils[left(no)] == EATING ||     // Wenn nur einer der Nachbarn isst, dann
           phils[right(no)] == EATING) {    // warte bis er fertig ist.
      try {
        wait ();
      } catch (InterruptedException e) {}
    }
    phils[no] = EATING;
  }
//-----------------------------------------------
  synchronized public void PutForks (int no) {
    phils[no] = NOTHING;                   // Markiere frei
    notifyAll ();                          // Nachricht an alle Wartende
  }
//-----------------------------------------------
  synchronized public void display () {
    String s = "Philosophen : ";
    for (int i = 0; i < N; i++)
      if (phils[i] == EATING) s = s + " " + i; // Ausgabe der momentan essenden Philosophen
    System.out.println (s);
  }
}
