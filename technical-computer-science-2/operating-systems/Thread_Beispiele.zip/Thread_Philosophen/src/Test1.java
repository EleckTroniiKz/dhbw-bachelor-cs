// Programm  :  F�nf Philosophen unter Java
// Lit.      :  W.Stallings, Operating Systems, Prentice Hall International 1995
//           :  A.S. Tanenbaum, Moderne Betriebssysteme, Carl Hanser Verlag, 1994 
//
// Der Manager handelt nach der Philosophie: gib nur dann Gabeln an einen
// Philosophen, wenn ALLE benoetigten Gabeln frei sind. Damit werden
// Deadlocks vermieden (vgl. Literaturangaben)
// 
public class Test1 {
	
	 public static void main (String args[]) 
	 {
		 Manager m = new Manager ();            // Manager zuerst anlegen
		 Thread p[] = new Thread [Manager.N];
		 for (int i = 0; i < p.length; i++) p[i] = new Philosopher (i, m); // die Philosophen anlegen
		 for (int i = 0; i < p.length; i++) p[i].start (); // f�r jeden Philosphen ein Thread starten
		 for (int i = 0; i < p.length; i++) {
		    try {
		      p[i].join (); // Warten auf das Ende der Threads
		      } catch (Exception e) {
		        System.err.println (e);
		      } // try-Block
		  } // For-Schleife
		    System.out.println("Programmende");
	} // Main-Methode
}
