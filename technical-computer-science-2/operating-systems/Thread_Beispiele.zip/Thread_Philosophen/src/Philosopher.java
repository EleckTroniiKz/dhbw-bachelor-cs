class Philosopher extends Thread {
  int no;                         // Die (unpersoenliche) Nummer des Philosophen
  Manager m;                      // Referenz zum Manager
// Methoden
  public Philosopher (int no, Manager m) {
    super ("Phil. " + no);
    this.no = no;
    this.m = m;
  } // Konstruktor

  void Eat () {
    m.display ();
    try {
      sleep (Math.round (1000.0*Math.random ()));
    }
    catch (InterruptedException e) {}
  } // Essen

  void Think () {
    try {
      sleep (Math.round (1000.0*Math.random ()));
    } catch (InterruptedException e) {}
  } // Denken

  public void run () {
    for (int j = 0; j < 5; j++) {
      Think ();                 // Denken ....
      m.TakeForks (no);         // Gabeln nehmen
      Eat ();                   // Essen
      m.PutForks (no);          // Gabeln ablegen
    }
  }
}