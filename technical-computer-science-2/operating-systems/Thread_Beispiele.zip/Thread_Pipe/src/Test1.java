// Klasse zum Testen der Pipe
public class Test1 {
	public static void main(String arg[]){
		Pipe pipe = new Pipe();
		Reader readerThread1 = new Reader(pipe);
		Reader readerThread2 = new Reader(pipe);
		Writer writerThread = new Writer(pipe);
		readerThread1.start();
		readerThread2.start();
		writerThread.start();
	}
}
