// Klasse, die in die Pipe beschreibt

public class Writer extends Thread {
	private Pipe pipe;
	private int[] sendeArray = {1,2,3,4,5,6,7,8,9,0}; // Mit 0 wird der Block terminiert
	public Writer(Pipe p){
		pipe = p;
	}
	public void run() {
		for (int i = 0; i < sendeArray.length;i++){
			pipe.write(sendeArray[i]);
			randomSleep(30);
		}
	}
	  public void randomSleep (int time) {
		    try {
		      sleep (Math.round (time*Math.random ()));
		    }
		    catch (InterruptedException e) {
		      System.out.println (e);
		    }
		  }
}
