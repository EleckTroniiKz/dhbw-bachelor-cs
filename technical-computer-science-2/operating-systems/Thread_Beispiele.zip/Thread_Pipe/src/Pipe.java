// Klasse Pipe mit maximal 3 Elemente

public class Pipe {
	private int[] array = new int[3];
	private int index = 0;
	
// Methoden
	
	public synchronized void write(int i) {
		if (index == array.length){
			System.out.println("Schreibender Thread muss warten");
			try {
				this.wait();
			} catch(InterruptedException e){
				System.out.println("InteruptedException");
				return;
			} // try-Block
		} // if-Block
		array[index] = i; // Wert i speichern
		index ++; // index erh�hen
		if(index == 1) this.notify(); // Leser aufwecken
		System.out.println("Wert:" + i + " gechrieben");
	} // write
	
	public synchronized int read() {
		int value;
		if (index == 0){ // Kein Wert vorhanden
			System.out.println("Lesender Thread muss warten");
			try {
				this.wait();
			} catch(InterruptedException e){
				
			} // try-Block
		} // if-Block
		value = array[0]; // Wert auslesen
		index --; // index erniedrigen
		for(int i = 0; i < index; i++)
			array[i]=array[i+1]; // Werte nach unten kopieren
		if(index == array.length-1) this.notify(); // Schreiber aufwecken
		System.out.println("Wert:" + value + " ausgegeben");
		return value;
	} // write
}
