// Klasse, die aus der Pipe liest
public class Reader extends Thread {
	private Pipe pipe;
// Methoden
	
	public Reader(Pipe p){
		pipe = p;
	} // Konstruktor
	
	public void run() {
		int empfang = 0;
		//while((empfang = pipe.read()) != 0); 
		while((empfang = pipe.read()) != 0) {// Eine 0 kennzeichnet das Ende des Empfangs
			randomSleep(50);
		}; 
	} // run
	  public void randomSleep (int time) {
		    try {
		      sleep (Math.round (time*Math.random ()));
		    }
		    catch (InterruptedException e) {
		      System.out.println (e);
		    }
		  }
}
