#include <unistd.h>
#include <stdio.h>
int main(int argc, char** args) {
	pid_t id;
switch(id = fork()){
	case -1: /*Fehler beim fork */
	printf("Fehler ... \n");
	break;
	case 0: /* Kindprozess */
	printf("Ich bin das Kind mit ID:%d\n",id);
	break;
	default: /*Erzeuger */
	printf("Ich bin der Ezeuger ID:%d\n",id);
	break;
}
return 0;
}
