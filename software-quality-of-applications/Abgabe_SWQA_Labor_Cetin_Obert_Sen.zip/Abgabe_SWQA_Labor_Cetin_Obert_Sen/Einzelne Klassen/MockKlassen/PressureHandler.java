package dhbw.kawumtest;

public class PressureHandler {

    private static String httpURL = "http://kawumAG.com/log/create/";
    private PressureReader pressureReader;
    private LogServer logServer;
    private IOHelper ioHelper;

    public PressureHandler(PressureReader pressureReader, LogServer logServer, IOHelper ioHelper){
        this.pressureReader = pressureReader;
        this.logServer = logServer;
        this.ioHelper = ioHelper;
    }

    private void sentLogEntryRequest(){
        // Replace the empty String in body, with a log Message, when communication with the developer of Kawum
        logServer.post(httpURL, "");
    }

    private void handleLowPressure(){
        ioHelper.setTriggerAcousticSignal(true);
        ioHelper.notifyOperationsManager();
        this.sentLogEntryRequest();
    }

    private void handleHighPressure(){
        ioHelper.setTriggerAcousticSignal(true);
        ioHelper.notifyOperationsManager();
        ioHelper.notifyMaintenanceTeam();
        this.sentLogEntryRequest();
    }

    private void handleUnderPressure(){
        ioHelper.notifyOperationsManager();
        ioHelper.notifyMaintenanceTeam();
        this.sentLogEntryRequest();
    }

    private void handleOverpressure(){
        ioHelper.notifyMaintenanceTeam();
        ioHelper.notifyOperationsManager();
        this.sentLogEntryRequest();
    }

    private void handleDangerousPressure(){
        ioHelper.setActivateAlarm(true);
        ioHelper.setInitializeEvacuation(true);
        this.sentLogEntryRequest();
    }

    public void checkPressure(){
        var pressure = pressureReader.getPressure();
        if(pressure > PressureValue.DANGEROUS_PRESSURE.getValue()){
            handleDangerousPressure();
        }
        else if(pressure > PressureValue.MAX_PRESSURE.getValue()){
            handleHighPressure();
        }
        else if(pressure >= PressureValue.MAX_FILL_PRESSURE.getValue()){
            handleOverpressure();
        }
        else if(pressure < PressureValue.MIN_PRESSURE.getValue()){
            handleLowPressure();
        }
        else if(pressure <= PressureValue.MIN_FILL_PRESSURE.getValue()){
            handleUnderPressure();
        }
    }
}
