package dhbw.kawumtest;

public class VoltageReader {

    private float voltage;

    public VoltageReader(){
    }

    public float getVoltage() {
        // This method will be mocked with the use of Mockito.
        // Later would be connected to the sensor.
        return voltage;
    }

    public void setVoltage(float voltage) {
        this.voltage = voltage;
    }


}
