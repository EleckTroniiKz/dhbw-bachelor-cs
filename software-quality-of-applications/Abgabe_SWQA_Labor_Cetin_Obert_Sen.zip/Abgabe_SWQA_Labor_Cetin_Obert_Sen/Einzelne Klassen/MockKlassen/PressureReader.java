package dhbw.kawumtest;

public class PressureReader {

    private float pressure;

    public PressureReader(){
    }

    public float getPressure(){
        //There the connection to the sensor is established and the data from it will be read
        return pressure;
    }

    public void setPressure(float pressure) {
        this.pressure = pressure;
    }
}
