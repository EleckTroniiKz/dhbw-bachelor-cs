package dhbw.kawumtest;

public enum PressureValue {

    MIN_PRESSURE(50),
    MAX_PRESSURE(300),
    MIN_FILL_PRESSURE(180),
    MAX_FILL_PRESSURE(220),
    DANGEROUS_PRESSURE(500);

    private final int value;

    PressureValue(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
