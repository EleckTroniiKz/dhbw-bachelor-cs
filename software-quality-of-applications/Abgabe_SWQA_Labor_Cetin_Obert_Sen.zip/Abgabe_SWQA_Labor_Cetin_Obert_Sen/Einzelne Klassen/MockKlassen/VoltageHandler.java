package dhbw.kawumtest;

public class VoltageHandler {


    private final IOHelper ioHelper;
    private final VoltageReader voltageReader;

    public VoltageHandler(VoltageReader voltageReader, IOHelper ioHelper){
        this.voltageReader = voltageReader;
        this.ioHelper = ioHelper;
    }

    public void checkVoltage(){
        if (voltageReader.getVoltage() < 5.0f){
            ioHelper.setTriggerAcousticSignal(true);
        }
    }

}
