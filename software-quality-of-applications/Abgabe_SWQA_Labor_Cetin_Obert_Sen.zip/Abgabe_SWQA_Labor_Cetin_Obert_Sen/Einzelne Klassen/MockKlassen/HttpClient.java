package dhbw.kawumtest;

public interface HttpClient {
    int get(String url);
    int post(String url, String body);
}