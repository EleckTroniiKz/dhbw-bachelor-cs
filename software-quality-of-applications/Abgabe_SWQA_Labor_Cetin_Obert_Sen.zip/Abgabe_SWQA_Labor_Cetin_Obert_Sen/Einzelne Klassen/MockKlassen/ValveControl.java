package dhbw.kawumtest;

public class ValveControl {

    public ValveControl(){
    }

    public Integer checkValveStatus(){
        // start valve control connection
        // Call 3rd Party Code from the Valve Control here to read the valve status
        // end valve control connection

        return 0;
    }
}
