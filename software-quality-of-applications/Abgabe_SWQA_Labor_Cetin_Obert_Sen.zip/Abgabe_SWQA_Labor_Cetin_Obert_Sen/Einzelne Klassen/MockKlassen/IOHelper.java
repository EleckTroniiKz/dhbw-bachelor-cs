package dhbw.kawumtest;

public class IOHelper {

    private static final String NOTIFY_MAINTENANCE_TEAM = "Notify maintenance team!";
    private static final String NOPTIFY_OPERATIONS_MANAGER = "Notify operations manager!";
    //true if signal is on and false if signal is off
    private boolean triggerAcousticSignal;
    private boolean activateAlarm;
    private boolean initializeEvacuation;

    public String notifyMaintenanceTeam() {
        return NOTIFY_MAINTENANCE_TEAM;
    }

    public String notifyOperationsManager() {
        return NOPTIFY_OPERATIONS_MANAGER;
    }

    public boolean getTriggerAcousticSignal() {
        return triggerAcousticSignal;
    }

    public void setTriggerAcousticSignal(boolean triggerAcousticSignal) {
        this.triggerAcousticSignal = triggerAcousticSignal;
    }

    public boolean getActivateAlarm() {
        return activateAlarm;
    }

    public void setActivateAlarm(boolean activateAlarm) {
        this.activateAlarm = activateAlarm;
    }

    public boolean getInitializeEvacuation() {
        return initializeEvacuation;
    }

    public void setInitializeEvacuation(boolean initializeEvacuation) {
        this.initializeEvacuation = initializeEvacuation;
    }
}