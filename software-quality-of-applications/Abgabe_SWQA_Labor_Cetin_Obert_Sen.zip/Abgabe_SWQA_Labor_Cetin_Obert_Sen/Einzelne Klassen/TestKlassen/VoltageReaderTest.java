package dhbw.kawumtest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

class VoltageReaderTest {
    VoltageReader voltageReader;

    float voltage = 5.0f;

    @BeforeEach
    void prepareTest(){
        voltageReader = new VoltageReader();
    }

    @Test
    void correctVoltageReading(){
        voltageReader.setVoltage(voltage);
        assertEquals(voltageReader.getVoltage(),voltage,"Read Voltage Value was not correct.");
    }

    @Test
    void incorrectVoltageReading(){
        voltageReader.setVoltage((-1) * voltage);
        assertNotEquals(voltageReader.getVoltage(),voltage,"Read Voltage Value was correct.");
    }
}
