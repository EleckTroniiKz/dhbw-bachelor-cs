package dhbw.kawumtest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;

class OptimalPressureTest {

    @Mock
    LogServer logServer;
    @Mock
    PressureReader pressureReader;
    @Mock
    IOHelper ioHelper;

    PressureHandler pressureHandler;
    float optimalPressure = (float) PressureValue.MIN_FILL_PRESSURE.getValue() + 1;

    @BeforeEach
    void prepareMocks() {
        logServer = mock(LogServer.class);
        pressureReader = Mockito.mock(PressureReader.class);
        ioHelper = Mockito.mock(IOHelper.class);
        pressureHandler = new PressureHandler(pressureReader, logServer, ioHelper);
    }

    @Test
    void optimalValueOperationManagerNotNotified() {
        when(pressureReader.getPressure()).thenReturn(optimalPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, never().description("Operation manager was FALSELY notified, while having a optimal pressure value.")).notifyOperationsManager();
    }

    @Test
    void optimalValueMaintenanceTeamNotNotified() {
        when(pressureReader.getPressure()).thenReturn(optimalPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, never().description("Maintenance team was FALSELY notified, while having a optimal pressure value.")).notifyMaintenanceTeam();
    }

    @Test
    void optimalValueLogEntryNotCreatedAndSent() {
        when(pressureReader.getPressure()).thenReturn(optimalPressure);
        pressureHandler.checkPressure();
        String logServerURL = "http://kawumAG.com/log/create/";
        // After communication with the dev from kawum replace string empty with a log Message
        verify(logServer, never().description("Log entry has been created and sent, although it was unexpected, because the pressure levels are optimal.")).post(logServerURL, "");
    }

    @Test
    void optimalValueEvacuationNotInitialised() {
        when(pressureReader.getPressure()).thenReturn(optimalPressure);
        pressureHandler.checkPressure();
        verify(ioHelper,never().description("Evacuation should not be initialized for optimal pressure values.")).setInitializeEvacuation(true);
    }

    @Test
    void optimalValueAcousticSignalNotActivated() {
        when(pressureReader.getPressure()).thenReturn(optimalPressure);
        pressureHandler.checkPressure();
        verify(ioHelper,never().description("Acoustic signal was activated for optimal pressure values, but it should not have been activated.")).setTriggerAcousticSignal(true);
    }

    @Test
    void optimalValueAlarmNotActivate() {
        when(pressureReader.getPressure()).thenReturn(optimalPressure);
        pressureHandler.checkPressure();
        verify(ioHelper,never().description("Alarm should stay deactivated for optimal pressure values, but it is activated.")).setActivateAlarm(true);
    }
}