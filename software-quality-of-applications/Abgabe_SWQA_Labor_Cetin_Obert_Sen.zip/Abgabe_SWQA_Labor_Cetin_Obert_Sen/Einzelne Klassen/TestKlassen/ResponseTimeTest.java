package dhbw.kawumtest;

import static org.junit.jupiter.api.Assertions.assertTimeout;
import static org.mockito.Mockito.mock;

import java.time.Duration;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class ResponseTimeTest {
    @Mock
    PressureReader pressureReader;
    @Mock
    LogServer logServer;
    @Mock
    IOHelper ioHelper;
    @Mock
    VoltageReader voltageReader;
    @Mock
    VoltageHandler voltageHandler;

    PressureHandler pressureHandler;
    int preferredDurationInMilliseconds = 10;

    @BeforeEach
    void prepareMock() {
        pressureReader = new PressureReader();
        logServer = new LogServer();
        ioHelper = new IOHelper();
        pressureHandler = new PressureHandler(pressureReader, logServer, ioHelper);
        voltageReader = new VoltageReader();
        voltageHandler = new VoltageHandler(voltageReader, ioHelper);
    }

    @Test
    void responseTimeCheckPressure() {
        assertTimeout(Duration.ofMillis(preferredDurationInMilliseconds), () -> {
            pressureHandler.checkPressure();
        }, "Maximum response time exceeded for pressure check in pressure handler!");
    }

    @Test
    void responseTimeGetPressure() {
        assertTimeout(Duration.ofMillis(preferredDurationInMilliseconds), () -> {
            pressureReader.getPressure();
        }, "Maximum response time exceeded for pressure reading!");
    }

    @Test
    void responseTimeGetVoltage() {
        assertTimeout(Duration.ofMillis(preferredDurationInMilliseconds), () -> {
            voltageReader.getVoltage();
        }, "Maximum response time exceeded for voltage reading!");
    }

    @Test
    void responseTimeCheckVoltage(){
        assertTimeout(Duration.ofMillis(preferredDurationInMilliseconds), () -> {
            voltageHandler.checkVoltage();
        }, "Maximum response time exceeded for voltage check in voltage handler!");
    }

    @Test
    void responseTimeNotifyMaintenanceTeam() {
        assertTimeout(Duration.ofMillis(preferredDurationInMilliseconds), () -> {
            ioHelper.notifyMaintenanceTeam();
        }, "Maximum response time exceeded for notifying maintenance team!");
    }

    @Test
    void responseTimeNotifyOperationsManager() {
        assertTimeout(Duration.ofMillis(preferredDurationInMilliseconds), () -> {
            ioHelper.notifyOperationsManager();
        }, "Maximum response time exceeded for notifying operations manager!");
    }

    @Test
    void responseTimeTriggerAcousticSignal() {
        assertTimeout(Duration.ofMillis(preferredDurationInMilliseconds), () -> {
            ioHelper.setTriggerAcousticSignal(true);
        }, "Maximum response time exceeded for triggering acoustic signal!");
    }

    @Test
    void responseTimeActivateAlarm() {
        assertTimeout(Duration.ofMillis(preferredDurationInMilliseconds), () -> {
            ioHelper.setActivateAlarm(true);
        }, "Maximum response time exceeded for activation of the alarm!");
    }

    @Test
    void responseTimeInitializeBuildingEvacuation() {
        assertTimeout(Duration.ofMillis(preferredDurationInMilliseconds), () -> {
            ioHelper.setInitializeEvacuation(true);
        }, "Maximum response time exceeded for initializing building evacuation!");
    }
}