package dhbw.kawumtest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;


class DangerousPressureTest {
    @Mock
    LogServer logServer;
    @Mock
    PressureReader pressureReader;
    @Mock
    IOHelper ioHelper;

    PressureHandler pressureHandler;
    float dangerousPressure = (float) PressureValue.DANGEROUS_PRESSURE.getValue() + 1;

    @BeforeEach
    void prepareMocks() {
        logServer = Mockito.mock(LogServer.class);
        pressureReader = Mockito.mock(PressureReader.class);
        ioHelper = Mockito.mock(IOHelper.class);
        pressureHandler = new PressureHandler(pressureReader, logServer, ioHelper);
    }

    @Test
    void dangerousValueLogEntryCreatedAndSent() {
        when(pressureReader.getPressure()).thenReturn(dangerousPressure);
        pressureHandler.checkPressure();
        String logServerURL = "http://kawumAG.com/log/create/";
        // After communication with the dev from kawum replace string empty with a log Message
        verify(logServer, description("Log entry has not been created and sent, although having a dangerous pressure value.")).post(logServerURL, "");
    }

    @Test
    void dangerousValueAlarmActivated() {
        when(pressureReader.getPressure()).thenReturn(dangerousPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, description("Alarm should be activated for dangerous pressure values, but it is deactivated.")).setActivateAlarm(true);
    }

    @Test
    void dangerousValueEvacuationInitialised() {
        when(pressureReader.getPressure()).thenReturn(dangerousPressure);
        pressureHandler.checkPressure();
        verify(ioHelper,description("Evacuation was not initialized although having dangerous pressure values.")).setInitializeEvacuation(true);
    }

    @Test
    void dangerousValueOperationManagerNotNotified() {
        when(pressureReader.getPressure()).thenReturn(dangerousPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, never().description("Operation manager was FALSELY notified, while having a dangerous pressure value.")).notifyOperationsManager();
    }

    @Test
    void dangerousValueMaintenanceTeamNotNotified() {
        when(pressureReader.getPressure()).thenReturn(dangerousPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, never().description("Maintenance team was FALSELY notified, while having a dangerous pressure value.")).notifyMaintenanceTeam();
    }

    @Test
    void dangerousValueAcousticSignalNotActivated() {
        when(pressureReader.getPressure()).thenReturn(dangerousPressure);
        pressureHandler.checkPressure();
        verify(ioHelper,never().description("Acoustic signal was activated for dangerous pressure values, but it should not have been activated.")).setTriggerAcousticSignal(true);
    }

}
