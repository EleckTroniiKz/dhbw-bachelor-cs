package dhbw.kawumtest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class ValveControlTest {
    ValveControl valveControl;
    @BeforeEach
    void prepare(){
        valveControl = new ValveControl();
    }

    @Test
    void valveControlStatus(){
        var result = valveControl.checkValveStatus();
        assertNotNull(result,"Valve Status is null.");
    }
}
