package dhbw.kawumtest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;

class MaximalPressureTest {

    @Mock
    LogServer logServer;
    @Mock
    PressureReader pressureReader;
    @Mock
    IOHelper ioHelper;

    PressureHandler pressureHandler;
    float maximalPressure = (float) PressureValue.MAX_PRESSURE.getValue() + 1;

    @BeforeEach
    void prepareMocks() {
        logServer = Mockito.mock(LogServer.class);
        pressureReader = Mockito.mock(PressureReader.class);
        ioHelper = Mockito.mock(IOHelper.class);
        pressureHandler = new PressureHandler(pressureReader, logServer, ioHelper);
    }

    @Test
    void maximalValueAcousticSignalActivated() {
        when(pressureReader.getPressure()).thenReturn(maximalPressure);
        pressureHandler.checkPressure();
        verify(ioHelper,description("Acoustic signal was not activated for maximal pressure values, but it should have been activated.")).setTriggerAcousticSignal(true);
    }

    @Test
    void maximalValueOperationManagerNotified() {
        when(pressureReader.getPressure()).thenReturn(maximalPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, description("Operation manager should have been notified, for a maximal pressure value, but wasn't.")).notifyOperationsManager();
    }

    @Test
    void maximalValueMaintenanceTeamNotified() {
        when(pressureReader.getPressure()).thenReturn(maximalPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, description("Maintenance Team should have been notified, for a maximal pressure value, but wasn't.")).notifyMaintenanceTeam();
    }

    @Test
    void maximalValueLogEntryCreatedAndSent() {
        when(pressureReader.getPressure()).thenReturn(maximalPressure);
        pressureHandler.checkPressure();
        String logServerURL = "http://kawumAG.com/log/create/";
        // After communication with the dev from kawum replace string empty with a log Message
        verify(logServer, description("Log entry has not been created and sent, although having a maximal pressure value.")).post(logServerURL, "");
    }

    @Test
    void maximalValueAlarmNotActivate() {
        when(pressureReader.getPressure()).thenReturn(maximalPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, never().description("Alarm should stay deactivated for maximal pressure values, but it is activated.")).setActivateAlarm(true);
    }

    @Test
    void maximalValueEvacuationNotInitialised() {
        when(pressureReader.getPressure()).thenReturn(maximalPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, never().description("Evacuation should not be initialized for maximal pressure values.")).setInitializeEvacuation(true);
    }

}
