package dhbw.kawumtest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;

class VoltageHandlerTest {

    @Mock
    VoltageReader voltageReader;
    @Mock
    IOHelper ioHelper;

    VoltageHandler voltageHandler;
    float voltageValue = 5.0f;

    @BeforeEach
    void prepareMocks() {
        voltageReader = mock(VoltageReader.class);
        ioHelper = Mockito.mock(IOHelper.class);
        voltageHandler = new VoltageHandler(voltageReader, ioHelper);
    }

    @Test
    void alarmTriggeredWhenLowVoltage() {
        when(voltageReader.getVoltage()).thenReturn(voltageValue-1);
        voltageHandler.checkVoltage();
        verify(ioHelper,description("The Acoustic Signal has not been triggered although the voltage was too low.")).setTriggerAcousticSignal(true);
    }

    @Test
    void alarmNotTriggeredWhenNormalVoltage() {
        when(voltageReader.getVoltage()).thenReturn(voltageValue);
        voltageHandler.checkVoltage();
        verify(ioHelper,never().description("The Acoustic Signal has been triggered although the voltage was not low.")).setTriggerAcousticSignal(true);
    }


}
