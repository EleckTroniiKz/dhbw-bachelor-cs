package dhbw.kawumtest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;
import static org.mockito.Mockito.never;

class OverPressureTest {


    @Mock
    LogServer logServer;
    @Mock
    PressureReader pressureReader;
    @Mock
    IOHelper ioHelper;

    PressureHandler pressureHandler;
    float overPressure = (float) PressureValue.MAX_FILL_PRESSURE.getValue() + 1;

    @BeforeEach
    void prepareMocks() {
        logServer = Mockito.mock(LogServer.class);
        pressureReader = Mockito.mock(PressureReader.class);
        ioHelper = Mockito.mock(IOHelper.class);
        pressureHandler = new PressureHandler(pressureReader, logServer, ioHelper);
    }

    @Test
    void overPressureValueOperationManagerNotified() {
        when(pressureReader.getPressure()).thenReturn(overPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, description("Operation manager should have been notified, for a over pressure value, but wasn't.")).notifyOperationsManager();
    }

    @Test
    void overPressureValueMaintenanceTeamNotified() {
        when(pressureReader.getPressure()).thenReturn(overPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, description("Maintenance team should have been notified, for a over pressure value, but wasn't.")).notifyMaintenanceTeam();
    }

    @Test
    void overPressureValueLogEntryCreatedAndSent() {
        when(pressureReader.getPressure()).thenReturn(overPressure);
        pressureHandler.checkPressure();
        String logServerURL = "http://kawumAG.com/log/create/";
        // After communication with the dev from kawum replace string empty with a log Message
        verify(logServer, description("Log entry has not been created and sent, although having a over pressure value.")).post(logServerURL, "");
    }

    @Test
    void overPressureValueAcousticSignalNotActivated() {
        when(pressureReader.getPressure()).thenReturn(overPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, never().description("Acoustic signal was activated for over pressure values, but it should not have been activated.")).setTriggerAcousticSignal(true);
    }

    @Test
    void overPressureValueAlarmNotActivate() {
        when(pressureReader.getPressure()).thenReturn(overPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, never().description("Alarm should stay deactivated for over pressure values, but it is activated.")).setActivateAlarm(true);
    }

    @Test
    void overPressureValueEvacuationNotInitialised() {
        when(pressureReader.getPressure()).thenReturn(overPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, never().description("Evacuation should not be initialized for over pressure values.")).setInitializeEvacuation(true);
    }
}