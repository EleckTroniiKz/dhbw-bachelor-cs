package dhbw.kawumtest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PressureReaderTest {
    PressureReader pressureReader;

    @BeforeEach
    void prepareTest(){
        pressureReader = new PressureReader();
    }

    @Test
    void correctPressureReading(){
        pressureReader.setPressure(5.0000f);
        assertEquals(pressureReader.getPressure(),5.0000f,"Read Pressure Value was not correct.");
    }

    @Test
    void incorrectPressureReading(){
        pressureReader.setPressure(-5.0000f);
        assertNotEquals(pressureReader.getPressure(),5.0000f,"Read Pressure Value was correct.");
    }
}
