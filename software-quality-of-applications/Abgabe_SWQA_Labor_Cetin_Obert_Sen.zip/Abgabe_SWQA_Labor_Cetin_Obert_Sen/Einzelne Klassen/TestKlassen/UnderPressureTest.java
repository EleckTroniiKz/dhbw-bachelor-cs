package dhbw.kawumtest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.mock;

class UnderPressureTest {

    @Mock
    LogServer logServer;
    @Mock
    PressureReader pressureReader;
    @Mock
    IOHelper ioHelper;

    PressureHandler pressureHandler;
    float underPressure = (float) PressureValue.MIN_FILL_PRESSURE.getValue() - 1;

    @BeforeEach
    void prepareMocks() {
        logServer = mock(LogServer.class);
        pressureReader = Mockito.mock(PressureReader.class);
        ioHelper = Mockito.mock(IOHelper.class);
        pressureHandler = new PressureHandler(pressureReader, logServer, ioHelper);
    }

    @Test
    void underPressureValueOperationManagerNotified() {
        when(pressureReader.getPressure()).thenReturn(underPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, description("Operation manager should have been notified, for a under pressure value, but wasn't.")).notifyOperationsManager();
    }

    @Test
    void underPressureValueMaintenanceTeamNotified() {
        when(pressureReader.getPressure()).thenReturn(underPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, description("Maintenance team should have been notified, for a under pressure value, but wasn't.")).notifyMaintenanceTeam();
    }

    @Test
    void underPressureValueLogEntryCreatedAndSent() {
        when(pressureReader.getPressure()).thenReturn(underPressure);
        pressureHandler.checkPressure();
        String logServerURL = "http://kawumAG.com/log/create/";
        // After communication with the dev from kawum replace string empty with a log Message
        verify(logServer, description("Log entry has not been created and sent, although having a under pressure value.")).post(logServerURL, "");
    }

    @Test
    void underPressureValueAcousticSignalNotActivated() {
        when(pressureReader.getPressure()).thenReturn(underPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, never().description("Acoustic signal was activated for under pressure values, but it should not have been activated.")).setTriggerAcousticSignal(true);
    }

    @Test
    void underPressureValueAlarmNotActivate() {
        when(pressureReader.getPressure()).thenReturn(underPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, never().description("Alarm should stay deactivated for under pressure values, but it is activated.")).setActivateAlarm(true);
    }

    @Test
    void underPressureValueEvacuationNotInitialised() {
        when(pressureReader.getPressure()).thenReturn(underPressure);
        pressureHandler.checkPressure();
        verify(ioHelper, never().description("Evacuation should not be initialized for under pressure values.")).setInitializeEvacuation(true);
    }

}