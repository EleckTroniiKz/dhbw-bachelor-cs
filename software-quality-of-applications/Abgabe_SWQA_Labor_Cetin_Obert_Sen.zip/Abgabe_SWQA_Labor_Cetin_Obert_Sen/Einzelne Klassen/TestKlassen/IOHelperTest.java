package dhbw.kawumtest;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class IOHelperTest {

    IOHelper ioHelper = new IOHelper();

    @Test
    void notifyMaintenanceTeam() {
        String result = ioHelper.notifyMaintenanceTeam();
        assertEquals("Notify maintenance team!", result, "Notify maintenance team method is not returning expected String.");
    }

    @Test
    void notifyOperationsManager() {
        String result = ioHelper.notifyOperationsManager();
        assertEquals("Notify operations manager!", result, "Notify operations manager method is not returning expected String.");
    }

    @Test
    void triggerAcousticSignal_Activated() {
        ioHelper.setTriggerAcousticSignal(true);
        assertTrue(ioHelper.getTriggerAcousticSignal(), "Acoustic Signal should be activated, but is deactivated.");
    }

    @Test
    void triggerAcousticSignal_NotActivated() {
        ioHelper.setTriggerAcousticSignal(false);
        assertFalse(ioHelper.getTriggerAcousticSignal(), "Acoustic Signal should be deactivated, but is activated.");
    }

    @Test
    void activateAlarm_Activated() {
        ioHelper.setActivateAlarm(true);
        assertTrue(ioHelper.getActivateAlarm(), "Alarm should be activated, but is deactivated.");
    }

    @Test
    void activateAlarm_NotActivated() {
        ioHelper.setActivateAlarm(false);
        assertFalse(ioHelper.getActivateAlarm(), "Alarm should be deactivated, but is activated.");
    }

    @Test
    void initializeBuildingEvacuation_Initialized() {
        ioHelper.setInitializeEvacuation(true);
        assertTrue(ioHelper.getInitializeEvacuation(), "Evacuation should have been initialized, but it was NOT.");
    }

    @Test
    void initializeBuildingEvacuation_NotInitialized() {
        ioHelper.setInitializeEvacuation(false);
        assertFalse(ioHelper.getInitializeEvacuation(), "Evacuation should NOT have been initialized, but it was.");
    }
}