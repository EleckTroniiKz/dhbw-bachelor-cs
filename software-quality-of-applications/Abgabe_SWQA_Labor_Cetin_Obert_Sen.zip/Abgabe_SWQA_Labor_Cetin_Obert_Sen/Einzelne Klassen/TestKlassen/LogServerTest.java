package dhbw.kawumtest;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LogServerTest {

    @Test
    void getRequest() {
        LogServer logServer = new LogServer();
        int statusCode = logServer.get("http://kawumAG.com/log/create/");
        assertEquals(LogServer.HttpStatus.OK.getCode(), statusCode);
    }

    @Test
    void postRequest() {
        LogServer logServer = new LogServer();
        int statusCode = logServer.post("http://kawumAG.com/log/create/", "SOMETHING");
        assertEquals(LogServer.HttpStatus.CREATED.getCode(), statusCode);
    }
}